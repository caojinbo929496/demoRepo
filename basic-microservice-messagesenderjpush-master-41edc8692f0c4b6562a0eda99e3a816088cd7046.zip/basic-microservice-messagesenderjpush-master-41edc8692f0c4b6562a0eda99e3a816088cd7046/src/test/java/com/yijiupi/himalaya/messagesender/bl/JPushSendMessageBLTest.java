package com.yijiupi.himalaya.messagesender.bl;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.yijiupi.himalaya.JPushMessageSenderApp;
import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;
import com.yijiupi.himalaya.basic.message.enums.PushAPPType;
import com.yijiupi.himalaya.basic.message.enums.PushType;
import com.yijiupi.himalaya.basic.messagesender.bl.JPushSendMessageBL;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = JPushMessageSenderApp.class)
public class JPushSendMessageBLTest {

	@Autowired
	private JPushSendMessageBL sendMessageBL;

	@Test
	public void testSend() {
		PushMessageDTO pushMessage = new PushMessageDTO();
		pushMessage.setPushAPPType(PushAPPType.E_JIU_PI);
		pushMessage.setContent("test");
		List<String> mobileList = new ArrayList<>();
		mobileList.add("817245914753140519");
		pushMessage.setTagOrIdList(mobileList);
		pushMessage.setPushType(PushType.用户推送);
		sendMessageBL.sendMessage(pushMessage);
	}
}
