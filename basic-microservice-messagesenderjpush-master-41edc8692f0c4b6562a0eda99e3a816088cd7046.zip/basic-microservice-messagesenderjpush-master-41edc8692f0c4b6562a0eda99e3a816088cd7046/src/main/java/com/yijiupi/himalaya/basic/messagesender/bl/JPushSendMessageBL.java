package com.yijiupi.himalaya.basic.messagesender.bl;

import java.util.ArrayList;
import java.util.List;

import com.yijiupi.himalaya.basic.messagesender.dto.PushMessageSenderDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;
import com.yijiupi.himalaya.basic.message.enums.PushType;
import com.yijiupi.himalaya.basic.messagesender.config.SPConfig;

import cn.jpush.api.JPushClient;
import cn.jpush.api.common.APIConnectionException;
import cn.jpush.api.common.APIRequestException;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.Notification;

@Component
public class JPushSendMessageBL {
	private static final Logger LOGGER = LoggerFactory.getLogger(JPushSendMessageBL.class);
	@Autowired
	SPConfig spConfig;
	@Autowired
	private Gson gson;

	/**
	 * 构建推送消息体
	 * 
	 * @param pushMessage
	 * @param tagOrIdList
	 * @return
	 * @return: PushPayload
	 */
	private PushPayload buildPushObject(PushMessageSenderDTO pushMessage, List<String> tagOrIdList) {

		String content = pushMessage.getContent();
		Integer pushType = pushMessage.getPushType();
		if (PushType.用户推送.value.equals(pushType)) {
			return PushPayload.newBuilder().setPlatform(Platform.all()).setAudience(Audience.alias(tagOrIdList))
					.setPlatform(Platform.android_ios()).setNotification(Notification.alert(content)).build();
		} else {
			return PushPayload.newBuilder().setPlatform(Platform.all()).setAudience(Audience.tag(tagOrIdList))
					.setPlatform(Platform.android_ios()).setNotification(Notification.alert(content)).build();
		}
	}

	/**
	 * 封装推送消息体并发送推送
	 * 
	 * @param pushMessage
	 * @param tagOrIdSize
	 * @return: void
	 */
	private void createPushPayloadAndPush(PushMessageSenderDTO pushMessage, int listSize) {

		// 获取推送APP配置信息
		Integer appId = pushMessage.getPushAPPType();
		JPushClient jpushClient = new JPushClient(spConfig.mastersecret(appId),
				spConfig.appkey(appId), 3);
		List<String> tagOrIdList = pushMessage.getTagOrIdList();
        int fromIndex = 0;
        int toIndex = listSize;
        while (toIndex + listSize <= tagOrIdList.size()) {
            PushPayload payload = buildPushObject(pushMessage, tagOrIdList.subList(fromIndex, toIndex));
            sendPush(jpushClient, payload);
            fromIndex = toIndex;
            toIndex = toIndex +  listSize;
        }
        if (toIndex + listSize > tagOrIdList.size()) {
            PushPayload payload = buildPushObject(pushMessage, tagOrIdList.subList(fromIndex, tagOrIdList.size()));
            sendPush(jpushClient, payload);
        }
	}

	public void sendMessage(PushMessageSenderDTO pushMessage) {

		// 极光推送tag一次最多20个
		int tagOrIdSize = 20;
		Integer pushType = pushMessage.getPushType();
		if (PushType.用户推送.value.equals(pushType)) {
			// 极光推送用户一次最多500个
			tagOrIdSize = 500;
		}
		createPushPayloadAndPush(pushMessage, tagOrIdSize);
	}

	/**
	 * 发送推送消息
	 * 
	 * @param jpushClient
	 * @param payload
	 * @return: void
	 */
	private void sendPush(JPushClient jpushClient, PushPayload payload) {

		try {
			PushResult res = jpushClient.sendPush(payload);
			LOGGER.info("极光推送结果：" + gson.toJson(res));
		} catch (APIConnectionException e) {
			LOGGER.error("极光推送连接失败！", e);
		} catch (APIRequestException e) {
			LOGGER.error("极光推送失败！", e);
		}
	}
}
