package com.yijiupi.himalaya.basic.messagesender.service;

import com.yijiupi.himalaya.basic.messagesender.common.ThreadLocalMallAppType;
import com.yijiupi.himalaya.basic.messagesender.dto.PushMessageSenderDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.google.gson.Gson;
import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;
import com.yijiupi.himalaya.basic.messagesender.bl.JPushSendMessageBL;

@Service
public class JPushSendMessageService implements ISendPushMessageService {
	private static final Logger LOGGER = LoggerFactory.getLogger(JPushSendMessageBL.class);
	@Autowired
	JPushSendMessageBL sendMessageBL;
	@Autowired
	private Gson gson;

	@Override
	public void sendMessage(PushMessageSenderDTO pushMessage) {
		LOGGER.info("收到极光推送请求：" + gson.toJson(pushMessage));
		ThreadLocalMallAppType.init(pushMessage.getMallAppType());
		sendMessageBL.sendMessage(pushMessage);
	}
}
