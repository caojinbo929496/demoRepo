package com.yijiupi.himalaya.basic.messagesender.config;

import java.util.Map;

import com.yijiupi.himalaya.basic.messagesender.enums.MallAppTypeAdapter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 极光推送接入配置信息.
 * 
 * @author: mxyong
 * @date: 2016年8月26日 上午10:53:53
 */
@ConfigurationProperties(prefix = "push")
public class SPConfig {
	private Map<MallAppTypeAdapter,Map<Integer, String>> title;

	private Map<MallAppTypeAdapter,Map<Integer, String>> appkey;

	private Map<MallAppTypeAdapter,Map<Integer, String>> mastersecret;

	public String title(Integer appId) {
        return MallAppTypeAdapter.getValue(title).get(appId);
    }

    public String appkey(Integer appId) {
        return MallAppTypeAdapter.getValue(appkey).get(appId);
    }

    public String mastersecret(Integer appId) {
        return MallAppTypeAdapter.getValue(mastersecret).get(appId);
    }

    public Map<MallAppTypeAdapter, Map<Integer, String>> getTitle() {
        return title;
    }

    public void setTitle(Map<MallAppTypeAdapter, Map<Integer, String>> title) {
        this.title = title;
    }

    public Map<MallAppTypeAdapter, Map<Integer, String>> getAppkey() {
        return appkey;
    }

    public void setAppkey(Map<MallAppTypeAdapter, Map<Integer, String>> appkey) {
        this.appkey = appkey;
    }

    public Map<MallAppTypeAdapter, Map<Integer, String>> getMastersecret() {
        return mastersecret;
    }

    public void setMastersecret(Map<MallAppTypeAdapter, Map<Integer, String>> mastersecret) {
        this.mastersecret = mastersecret;
    }
}
