package com.yijiupi.himalaya;

import java.util.concurrent.CountDownLatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.yijiupi.himalaya.basic.messagesender.config.SPConfig;

/**
 * 极光推送微服务
 */
@SpringBootApplication
@EnableConfigurationProperties(SPConfig.class)
public class JPushMessageSenderApp {
	/**
	 * 短信微服务主线程入口
	 * 
	 * @param args
	 * @throws InterruptedException
	 * @return: void
	 */
	public static void main(String[] args) throws InterruptedException {

		SpringApplication app = new SpringApplication(JPushMessageSenderApp.class);
		app.setWebEnvironment(false);// 不启动WEB 环境
		app.run(args);
		CountDownLatch latch = new CountDownLatch(1);
		latch.await();
	}
}
