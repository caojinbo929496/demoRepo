package com.yijiupi.himalaya.basic.messagesender.enums;

import com.yijiupi.himalaya.base.enums.MallAppType;
import com.yijiupi.himalaya.basic.messagesender.common.ThreadLocalMallAppType;

import java.util.Map;
import java.util.Objects;

/**
 * 商城类型适配器.
 * 获取指定商城类型的属性值
 */
public enum MallAppTypeAdapter {
    jiupi,zhangpi;

    /**
     * 将商城类型转成对应的Key
     */
    private static MallAppTypeAdapter converter() {
        MallAppType mallAppType = ThreadLocalMallAppType.get();
        if (Objects.equals(mallAppType, MallAppType.掌批)) {
            return zhangpi;
        }
        if (Objects.equals(mallAppType, MallAppType.酒批)) {
            return jiupi;
        }
        return jiupi;
    }

    /**
     * 默认类型
     */
    private static MallAppTypeAdapter defaultType() {
        return jiupi;
    }

    /**
     * 通过商城类型获取对应的属性
     */
    public static <T> T getValue(Map<MallAppTypeAdapter, T> map) {
        T value = map.get(MallAppTypeAdapter.converter());
        if (value == null) {
            value =  map.get(MallAppTypeAdapter.defaultType());
        }
        return value;
    }

    /**
     * 获取签名
     */
    public static String getSignature() {
        if (Objects.equals(ThreadLocalMallAppType.get(), MallAppType.掌批)) {
            return "【掌批】";
        }
        return "【易酒批】";
    }
}
