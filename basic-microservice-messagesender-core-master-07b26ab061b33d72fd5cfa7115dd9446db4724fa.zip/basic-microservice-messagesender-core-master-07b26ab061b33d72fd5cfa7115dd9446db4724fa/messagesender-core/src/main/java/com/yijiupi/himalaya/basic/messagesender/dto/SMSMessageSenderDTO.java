package com.yijiupi.himalaya.basic.messagesender.dto;

import com.yijiupi.himalaya.base.enums.MallAppType;

import java.util.ArrayList;
import java.util.List;

/**
 * 短消息DTO对象
 */
public class SMSMessageSenderDTO implements java.io.Serializable{
    /**
     * 短信内容；必填
     */
    private String content;
    /**
     * 发送短信的手机号码，多个手机号码用英文逗号隔开
     */
    private List<String> mobileList = new ArrayList<>();

    /**
     * 所属APP，默认酒批
     */
    private MallAppType mallAppType = MallAppType.酒批;

    public String getContent() {

        return content;
    }

    public void setContent(String content) {

        this.content = content;
    }

    public List<String> getMobileList() {

        return mobileList;
    }

    public void setMobileList(List<String> mobileList) {

        this.mobileList = mobileList;
    }

    public MallAppType getMallAppType() {
        return mallAppType;
    }

    public void setMallAppType(MallAppType mallAppType) {
        this.mallAppType = mallAppType;
    }
}
