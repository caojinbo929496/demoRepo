package com.yijiupi.himalaya.basic.messagesender.service;

import com.yijiupi.himalaya.basic.messagesender.dto.VoiceMessageSenderDTO;

/**
 * 语音验证发送服务.
 * 
 * @author: mxyong
 * @date: 2016年8月29日 下午1:26:08
 */
public interface ISendVoiceMessageService {

	String sendMessage(VoiceMessageSenderDTO voiceMessage);

}
