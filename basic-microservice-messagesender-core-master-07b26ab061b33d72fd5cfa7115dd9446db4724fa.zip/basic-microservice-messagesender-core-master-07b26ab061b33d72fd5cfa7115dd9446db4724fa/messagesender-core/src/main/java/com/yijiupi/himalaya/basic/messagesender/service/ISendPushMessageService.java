package com.yijiupi.himalaya.basic.messagesender.service;

import com.yijiupi.himalaya.basic.messagesender.dto.PushMessageSenderDTO;

public interface ISendPushMessageService {
	/**
	 * 发送短信消息.
	 * 
	 * @param sMessage
	 * @return: void
	 */
	void sendMessage(PushMessageSenderDTO pushMessage);
}
