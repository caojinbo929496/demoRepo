package com.yijiupi.himalaya.basic.messagesender.service;

import com.yijiupi.himalaya.basic.messagesender.dto.SMSMessageSenderDTO;

public interface ISendSMSMessageService {
	/**
	 * 发送短信消息.
	 * 
	 * @param sMessage
	 * @return: void
	 */
	String sendMessage(SMSMessageSenderDTO sMessage);
}
