package com.yijiupi.himalaya.basic.messagesender.common;

import com.yijiupi.himalaya.base.enums.MallAppType;
import com.yijiupi.himalaya.base.exception.BusinessValidateException;

/**
 * 商城类型线程变量处理类
 * @author zhouxin
 */
public class ThreadLocalMallAppType {


    private final static ThreadLocal<MallAppType> mallAppTypeThreadLocal = new ThreadLocal<>();

    public static void init(MallAppType mallAppType) {
        mallAppTypeThreadLocal.set(mallAppType);
    }

    public static MallAppType get() {
        MallAppType mallAppType = mallAppTypeThreadLocal.get();
        if (mallAppType == null) {
            mallAppTypeThreadLocal.set(MallAppType.酒批);
            return MallAppType.酒批;
        }
        return mallAppType;
    }

}
