package com.yijiupi.himalaya.basic.messagesender.service;

import com.yijiupi.himalaya.basic.messagesender.dto.SMSMessageSenderDTO;

/**
 * 发送1.0 系统群发短信
 */
public interface ISendV1SMSMessageService {
    /**
     * 发送短信消息.
     *
     * @param sMessage
     * @return: void
     */
    String sendMessage(SMSMessageSenderDTO sMessage);
}
