package com.yijiupi.himalaya.basic.messagesender.dto;

import com.yijiupi.himalaya.base.enums.MallAppType;

import java.util.List;

/**
 * 消息推送DTO
 */
public class PushMessageSenderDTO implements java.io.Serializable{

    private String content;
    private Integer pushAPPType;
    private Integer pushType;
    private List<String> tagOrIdList;

    /**
     * 所属APP，默认酒批
     */
    private MallAppType mallAppType = MallAppType.酒批;

    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getPushAPPType() {
        return pushAPPType;
    }

    public void setPushAPPType(Integer pushAPPType) {
        this.pushAPPType = pushAPPType;
    }

    public Integer getPushType() {
        return pushType;
    }

    public void setPushType(Integer pushType) {
        this.pushType = pushType;
    }

    public List<String> getTagOrIdList() {
        return tagOrIdList;
    }

    public void setTagOrIdList(List<String> tagOrIdList) {
        this.tagOrIdList = tagOrIdList;
    }

    public MallAppType getMallAppType() {
        return mallAppType;
    }

    public void setMallAppType(MallAppType mallAppType) {
        this.mallAppType = mallAppType;
    }
}
