package com.yijiupi.himalaya.basic.messagesender.message.cmpp;

import com.yijiupi.himalaya.basic.messagesender.util.ByteUtility;
import com.yijiupi.himalaya.basic.messagesender.util.DateFormater;
import com.yijiupi.himalaya.basic.messagesender.util.NetBits;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


/**
 * 下行消息请求.
 */
public class SubmitRequest extends CmppMessage {
	public static List<SubmitRequest> convert(String msg, String service_Id, String msg_src, String src_Id,
			String feeType, String feeCode, int registered_Delivery, boolean longSMS, boolean isSign, int signLength) {
		return convert("", msg, service_Id, msg_src, src_Id, feeType, feeCode, registered_Delivery, longSMS, isSign,
				signLength);
	}

	/**
	 * 根据短信内容长度转换成对应的短信下行消息.
	 * 
	 * @param mobile
	 * @param msg
	 * @param service_Id
	 * @param msg_src
	 * @param src_Id
	 * @param feeType
	 * @param feeCode
	 * @param registered_Delivery
	 * @param longSMS
	 *            是否按长短信方式，如果为否则进行分条.
	 * @return
	 * @return: List<SubmitRequest>
	 */
	public static List<SubmitRequest> convert(String mobile, String msg, String service_Id, String msg_src,
			String src_Id, String feeType, String feeCode, int registered_Delivery, boolean longSMS, boolean isSign,
			int signLength) {
		List<SubmitRequest> cmppMessageList = new ArrayList<>();

		// 内容长度大于70且按长短信方式发送
		if (msg.length() > 70 && longSMS) {
			List<String> msgs = CmppMessage.msgSegmentation(msg, 65, false, isSign, signLength);
			int randomKey = new Random().nextInt(255) + 1;
			int index = 1;
			for (String content : msgs) {
				SubmitRequest submitRequest2 = new SubmitRequest(mobile, content, service_Id, msg_src, src_Id, feeType,
						feeCode, registered_Delivery, true);
				submitRequest2.setTp_Udhi(1);
				submitRequest2.setMsg_Fmt(8);
				submitRequest2.setPk_Number(index);
				submitRequest2.setPk_Total(msgs.size());
				byte[] head = new byte[6];
				head[0] = 0x05;
				head[1] = 0x00;
				head[2] = 0x03;
				head[3] = (byte) (randomKey);
				head[4] = (byte) (msgs.size());
				head[5] = (byte) (index);
				submitRequest2.longHead = head;
				index++;

				cmppMessageList.add(submitRequest2);
			}
		}
		// 内容长度大于70按分条方式发送
		else if (msg.length() > 70) {
			List<String> msgs = CmppMessage.msgSegmentation(msg, 65, true, isSign, signLength);
			for (String content : msgs) {
				SubmitRequest submitRequest2 = new SubmitRequest(mobile, content, service_Id, msg_src, src_Id, feeType,
						feeCode, registered_Delivery, false);
				cmppMessageList.add(submitRequest2);
			}

		}
		// 内容长度小于70
		else {
			SubmitRequest submitRequest2 = new SubmitRequest(mobile, msg, service_Id, msg_src, src_Id, feeType, feeCode,
					registered_Delivery, false);
			cmppMessageList.add(submitRequest2);
		}

		return cmppMessageList;
	}

	private String at_Time = "";// 定时发送时间
	private byte[] content;
	private String custom_msg_id;// 客户端信息标识
	private String dest_Terminal_Id = "";// 接收短信的MSISDN号码
	private int destUsr_tl = 1;// 接收信息的用户数量(小于100个用户)
	private String fee_Terminal_Id = "";// 被计费用户的号码
	private int fee_UserType = 0;// 计费用户类型字段
	private String feeCode = "";// 资费代码
	private String feeType = "";// 资费类别
	private boolean isLongSMS = false;// 是否长短信
	private boolean isWAPPUSH = false;// 是否WAPPUSH
	private byte[] longHead = null;
	private String msg_Content = " ";// 信息内容
	private int msg_Fmt = 15;// 信息格式
	private String msg_Id;// 信息标识
	private int msg_Length = 0;// 信息长度(Msg_Fmt值为0时：<160个字节；其它<=140个字节)
	private int msg_Level = 0;// 信息级别
	private String msg_Src = "";// 信息内容来源(SP_Id)
	private int pk_Number = 1;// 相同Msg_Id的信息序号
	private int pk_Total = 1;// 相同Msg_Id的信息总条数

	private int registered_Delivery = 0;// 是否要求返回状态确认报告
	private String reserve = "";
	private String service_Id = "";// 业务标识
	private String src_Id = "";// 源号码

	private int status = -1;// 应答状态

	private int tp_PId = 0;// GSM协议类型

	private int tp_Udhi = 0;// GSM协议类型

	private String valid_Time = "";// 存活有效期

	private byte[] wappushbody = null;// WAPPUSH的内容体

	public SubmitRequest() {
		super(CID_CMPP_SUBMIT, createSeqNum());
	}

	public SubmitRequest(String mobile, String msg, String service_Id, String msg_src, String src_Id, String feeType,
			String feeCode, int registered_Delivery, boolean longSMS) {
		super(CID_CMPP_SUBMIT, createSeqNum());
		this.dest_Terminal_Id = mobile;
		this.msg_Content = msg;
		this.service_Id = service_Id;
		this.msg_Src = msg_src;
		this.src_Id = src_Id;
		this.feeType = feeType;
		this.feeCode = feeCode;
		this.registered_Delivery = registered_Delivery;
		this.isLongSMS = longSMS;
	}

	@Override
	public void decodeBody(byte[] body) throws Exception {
		int index = 0;
		msg_Id = Long.toUnsignedString(NetBits.getLong(body, 8));
		index += 8;
		pk_Total = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		pk_Number = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		registered_Delivery = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		msg_Level = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		service_Id = NetBits.getString(body, index, 10);
		index += 10;
		fee_UserType = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		fee_Terminal_Id = NetBits.getString(body, index, 21);
		index += 21;
		tp_PId = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		tp_Udhi = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		msg_Fmt = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		msg_Src = NetBits.getString(body, index, 6);
		index += 6;
		feeType = NetBits.getString(body, index, 2);
		index += 2;
		feeCode = NetBits.getString(body, index, 6);
		index += 6;
		valid_Time = NetBits.getString(body, index, 17);
		index += 17;
		at_Time = NetBits.getString(body, index, 17);
		index += 17;
		src_Id = NetBits.getString(body, index, 21);
		index += 21;
		destUsr_tl = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;

		dest_Terminal_Id = NetBits.getString(body, index, 21 * destUsr_tl);
		index += 21 * destUsr_tl;

		msg_Length = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;

		content = NetBits.getBytes(body, index, msg_Length);
		// 上行长短信的解码
		if (tp_Udhi == 1 && msg_Fmt == 8 && content.length > 6) {
			byte length = content[0];
			byte secondByte = content[1];
			byte threeByte = content[2];
			if ((length == 5 && secondByte == 0 && threeByte == 3)
					|| (length == 6 && secondByte == 8 && threeByte == 4)) {
				if (content.length > length + 1) {
					byte[] pkBytes = new byte[length + 1];
					System.arraycopy(content, 0, pkBytes, 0, length + 1);
					// pk_Number = pkBytes[length];
					// pk_Total = pkBytes[length - 1];
					isLongSMS = true;

					byte[] newContent = new byte[content.length - length - 1];
					System.arraycopy(content, length + 1, newContent, 0, newContent.length);

					msg_Content = ByteUtility.getMsgContentString(newContent, msg_Fmt);
				} else {
					msg_Content = null;
				}
			} else {
				msg_Content = ByteUtility.getMsgContentString(content, msg_Fmt);
			}
		} else { // 普通上行
			msg_Content = ByteUtility.getMsgContentString(content, msg_Fmt);
		}

		index += msg_Length;
		reserve = NetBits.getString(body, index, 8);
	}

	@Override
	public byte[] encodeBody() {
		if (!isWAPPUSH) {
			if (msg_Content == null) {
				if (this.msg_Fmt == MESSAGE_FMT_ASCII)
					msg_Length = 140;
				else
					msg_Length = 160;
			} else if (isLongSMS) {
				byte[] bodyBytes;

				bodyBytes = ByteUtility.getMsgContent(msg_Content, CmppMessage.MESSAGE_FMT_UCS2);

				content = new byte[longHead.length + bodyBytes.length];
				System.arraycopy(longHead, 0, content, 0, longHead.length);
				System.arraycopy(bodyBytes, 0, content, longHead.length, bodyBytes.length);
				msg_Length = content.length;
			} else {
				// 获取编码后内容
				if (tp_Udhi == 0)
					content = ByteUtility.getMsgContent(msg_Content, msg_Fmt);
				else
					content = msg_Content.getBytes();
				msg_Length = content.length;
			}
		} else {
			content = wappushbody;
			msg_Length = content.length;
		}

		int index = 0;
		byte[] msg = new byte[MESSAGE_SUBMIT_BODY_LEN_CMPP2 + msg_Length];

		index = 0;
		NetBits.putLong(msg, index, 0);
		index += 8;
		ByteUtility.putIntToBytes(msg, index, pk_Total, 1);
		index += 1;
		ByteUtility.putIntToBytes(msg, index, pk_Number, 1);
		index += 1;
		ByteUtility.putIntToBytes(msg, index, registered_Delivery, 1);
		index += 1;
		ByteUtility.putIntToBytes(msg, index, msg_Level, 1);
		index += 1;
		ByteUtility.putFixedStringToBytes(msg, index, service_Id, 10);
		index += 10;
		ByteUtility.putIntToBytes(msg, index, fee_UserType, 1);
		index += 1;
		ByteUtility.putFixedStringToBytes(msg, index, fee_Terminal_Id, 21);
		index += 21;
		ByteUtility.putIntToBytes(msg, index, tp_PId, 1);
		index += 1;
		ByteUtility.putIntToBytes(msg, index, tp_Udhi, 1);
		index += 1;
		ByteUtility.putIntToBytes(msg, index, msg_Fmt, 1);
		index += 1;
		ByteUtility.putFixedStringToBytes(msg, index, msg_Src, 6);
		index += 6;
		ByteUtility.putFixedStringToBytes(msg, index, feeType, 2);
		index += 2;
		ByteUtility.putFixedStringToBytes(msg, index, feeCode, 6);
		index += 6;

		// 时间转换
		String extime = "";
		String attime = "";

		if (!valid_Time.equals(""))
			extime = DateFormater.getCmppDateStr(valid_Time);

		if (!at_Time.equals(""))
			attime = DateFormater.getCmppDateStr(at_Time);

		ByteUtility.putFixedStringToBytes(msg, index, extime, 17);
		index += 17;
		ByteUtility.putFixedStringToBytes(msg, index, attime, 17);
		index += 17;
		ByteUtility.putFixedStringToBytes(msg, index, src_Id, 21);
		index += 21;
		ByteUtility.putIntToBytes(msg, index, destUsr_tl, 1);
		index += 1;
		ByteUtility.putFixedStringToBytes(msg, index, dest_Terminal_Id, 21);
		index += 21;
		ByteUtility.putIntToBytes(msg, index, msg_Length, 1);
		index += 1;
		NetBits.putBytes(msg, index, content);
		index += content.length;
		ByteUtility.putFixedStringToBytes(msg, index, reserve, 8);

		return msg;
	}

	public String getAt_Time() {
		return at_Time;
	}

	public byte[] getContent() {
		return content;
	}

	public String getCustom_msg_id() {
		return custom_msg_id;
	}

	public String getDest_Terminal_Id() {
		return dest_Terminal_Id;
	}

	public int getDestUsr_tl() {
		return destUsr_tl;
	}

	public String getFee_Terminal_Id() {
		return fee_Terminal_Id;
	}

	public int getFee_UserType() {
		return fee_UserType;
	}

	public String getFeeCode() {
		return feeCode;
	}

	public String getFeeType() {
		return feeType;
	}

	public byte[] getLongHead() {
		return longHead;
	}

	public String getMsg_Content() {
		return msg_Content;
	}

	public int getMsg_Fmt() {
		return msg_Fmt;
	}

	public String getMsg_Id() {
		return msg_Id;
	}

	public int getMsg_Length() {
		return msg_Length;
	}

	public int getMsg_Level() {
		return msg_Level;
	}

	public String getMsg_Src() {
		return msg_Src;
	}

	@Override
	public String getName() {
		return CMPP_SUBMIT;
	}

	public int getPk_Number() {
		return pk_Number;
	}

	public int getPk_Total() {
		return pk_Total;
	}

	public int getRegistered_Delivery() {
		return registered_Delivery;
	}

	public String getReserve() {
		return reserve;
	}

	public String getService_Id() {
		return service_Id;
	}

	public String getSrc_Id() {
		return src_Id;
	}

	public int getStatus() {
		return status;
	}

	public int getTp_PId() {
		return tp_PId;
	}

	public int getTp_Udhi() {
		return tp_Udhi;
	}

	public String getValid_Time() {
		return valid_Time;
	}

	public String getValId_Time() {
		return valid_Time;
	}

	public byte[] getWappushbody() {
		return wappushbody;
	}

	public boolean isLongSMS() {
		return isLongSMS;
	}

	public boolean isWAPPUSH() {
		return isWAPPUSH;
	}

	public void setAt_Time(String at_Time) {
		this.at_Time = at_Time;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}

	public void setCustom_msg_id(String custom_msg_id) {
		this.custom_msg_id = custom_msg_id;
	}

	public void setDest_Terminal_Id(String dest_Terminal_Id) {
		this.dest_Terminal_Id = dest_Terminal_Id;
	}

	public void setDestUsr_tl(int destUsr_tl) {
		this.destUsr_tl = destUsr_tl;
	}

	public void setFee_Terminal_Id(String fee_Terminal_Id) {
		this.fee_Terminal_Id = fee_Terminal_Id;
	}

	public void setFee_UserType(int fee_UserType) {
		this.fee_UserType = fee_UserType;
	}

	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public void setLongHead(byte[] longHead) {
		this.longHead = longHead;
	}

	public void setLongSMS(boolean isLongSMS) {
		this.isLongSMS = isLongSMS;
	}

	public void setMsg_Content(String msg_Content) {
		this.msg_Content = msg_Content;
	}

	public void setMsg_Fmt(int msg_Fmt) {
		this.msg_Fmt = msg_Fmt;
	}

	public void setMsg_Id(String msg_Id) {
		this.msg_Id = msg_Id;
	}

	public void setMsg_Length(int msg_Length) {
		this.msg_Length = msg_Length;
	}

	public void setMsg_Level(int msg_Level) {
		this.msg_Level = msg_Level;
	}

	public void setMsg_Src(String msg_Src) {
		this.msg_Src = msg_Src;
	}

	public void setPk_Number(int pk_Number) {
		this.pk_Number = pk_Number;
	}

	public void setPk_Total(int pk_Total) {
		this.pk_Total = pk_Total;
	}

	public void setRegistered_Delivery(int registered_Delivery) {
		this.registered_Delivery = registered_Delivery;
	}

	public void setReserve(String reserve) {
		this.reserve = reserve;
	}

	public void setService_Id(String service_Id) {
		this.service_Id = service_Id;
	}

	public void setSrc_Id(String src_Id) {
		this.src_Id = src_Id;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public void setTp_PId(int tp_PId) {
		this.tp_PId = tp_PId;
	}

	public void setTp_Udhi(int tp_Udhi) {
		this.tp_Udhi = tp_Udhi;
	}

	public void setValid_Time(String valid_Time) {
		this.valid_Time = valid_Time;
	}

	public void setValId_Time(String valId_Time) {
		this.valid_Time = valId_Time;
	}

	public void setWAPPUSH(boolean isWAPPUSH) {
		this.isWAPPUSH = isWAPPUSH;
	}

	public void setWappushbody(byte[] wappushbody) {
		this.wappushbody = wappushbody;
	}

}