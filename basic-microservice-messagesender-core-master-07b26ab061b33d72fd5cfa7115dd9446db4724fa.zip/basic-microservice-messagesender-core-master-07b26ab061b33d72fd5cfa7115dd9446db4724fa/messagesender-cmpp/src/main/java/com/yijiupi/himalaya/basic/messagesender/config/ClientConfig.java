package com.yijiupi.himalaya.basic.messagesender.config;

import com.yijiupi.himalaya.basic.messagesender.enums.MallAppTypeAdapter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;

/**
 * 接入运营商配置.
 * 
 * @author: mxyong
 */
@ConfigurationProperties(prefix = "cmpp")
public class ClientConfig {
	/**
	 * 与短信网关的连接数
	 */
	private Map<MallAppTypeAdapter, Integer> connectNum;
	/**
	 * 每秒发送的流量
	 */
	private Map<MallAppTypeAdapter, Integer> flow;

	/**
	 * 短信网关端口号
	 */
	private Map<MallAppTypeAdapter, Integer> port;

	/**
	 * 短信网关IP地址
	 */
	private Map<MallAppTypeAdapter, String> server;

	/**
	 * 连接密码
	 */
	private Map<MallAppTypeAdapter, String> sharedSecret;

	/**
	 * 企业代码
	 */
	private Map<MallAppTypeAdapter, String> sourceAddr;
	/**
	 * 源号码.
	 */
	private Map<MallAppTypeAdapter, String> srcId;

	public Integer connectNum() {
		return MallAppTypeAdapter.getValue(connectNum);
	}

	public Integer flow() {
		return MallAppTypeAdapter.getValue(flow);
	}

	public Integer port() {
		return MallAppTypeAdapter.getValue(port);
	}

	public String server() {
		return MallAppTypeAdapter.getValue(server);
	}

	public String sharedSecret() {
		return MallAppTypeAdapter.getValue(sharedSecret);
	}

	public String sourceAddr() {
		return MallAppTypeAdapter.getValue(sourceAddr);
	}

	public String srcId() {
		return MallAppTypeAdapter.getValue(srcId);
	}

	public Map<MallAppTypeAdapter, Integer> getConnectNum() {
		return connectNum;
	}

	public void setConnectNum(Map<MallAppTypeAdapter, Integer> connectNum) {
		this.connectNum = connectNum;
	}

	public Map<MallAppTypeAdapter, Integer> getFlow() {
		return flow;
	}

	public void setFlow(Map<MallAppTypeAdapter, Integer> flow) {
		this.flow = flow;
	}

	public Map<MallAppTypeAdapter, Integer> getPort() {
		return port;
	}

	public void setPort(Map<MallAppTypeAdapter, Integer> port) {
		this.port = port;
	}

	public Map<MallAppTypeAdapter, String> getServer() {
		return server;
	}

	public void setServer(Map<MallAppTypeAdapter, String> server) {
		this.server = server;
	}

	public Map<MallAppTypeAdapter, String> getSharedSecret() {
		return sharedSecret;
	}

	public void setSharedSecret(Map<MallAppTypeAdapter, String> sharedSecret) {
		this.sharedSecret = sharedSecret;
	}

	public Map<MallAppTypeAdapter, String> getSourceAddr() {
		return sourceAddr;
	}

	public void setSourceAddr(Map<MallAppTypeAdapter, String> sourceAddr) {
		this.sourceAddr = sourceAddr;
	}

	public Map<MallAppTypeAdapter, String> getSrcId() {
		return srcId;
	}

	public void setSrcId(Map<MallAppTypeAdapter, String> srcId) {
		this.srcId = srcId;
	}
}
