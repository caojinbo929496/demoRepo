package com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.ActiverTestRequest;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.ActiverTestResponse;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * 链路检测消息处理.
 * 
 * @author: mxyong
 */
@Component(CmppMessage.CMPP_ACTIVETEST)
public class ActiveTestRequestHandler implements CMPPMessageHandler {
	private static final Logger logger = LoggerFactory.getLogger(ActiveTestRequestHandler.class);

	@Override
	public void handle(IoSession session, CmppMessage message) {
		logger.debug("收到链路检测包.");
		ActiverTestRequest atr = (ActiverTestRequest) message;

		ActiverTestResponse atrp = new ActiverTestResponse(atr.getMessageSequence());

		session.write(atrp);
	}

}
