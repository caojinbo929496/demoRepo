
package com.yijiupi.himalaya.basic.messagesender.message.cmpp;

import java.io.Serializable;

/**
 * 
 * 状态报告
 */

public class StatusReport implements Serializable {
	private String dest_terminal_Id;
	private String done_time;
	private String msg_Id;
	private Integer sms_sequence;
	private String src_Id;
	private String stat;
	private String submit_time;

	public StatusReport() {

	}

	public String getDest_terminal_Id() {
		return dest_terminal_Id;
	}

	public String getDone_time() {
		return done_time;
	}

	public String getMsg_Id() {
		return msg_Id;
	}

	public Integer getSms_sequence() {
		return sms_sequence;
	}

	public String getSrc_Id() {
		return src_Id;
	}

	public String getStat() {
		return stat;
	}

	public String getSubmit_time() {
		return submit_time;
	}

	public void setDest_terminal_Id(String dest_terminal_Id) {
		this.dest_terminal_Id = dest_terminal_Id;
	}

	public void setDone_time(String done_time) {
		this.done_time = done_time;
	}

	public void setMsg_Id(String msg_Id) {
		this.msg_Id = msg_Id;
	}

	public void setSms_sequence(Integer sms_sequence) {
		this.sms_sequence = sms_sequence;
	}

	public void setSrc_Id(String src_Id) {
		this.src_Id = src_Id;
	}

	public void setStat(String stat) {
		this.stat = stat;
	}

	public void setSubmit_time(String submit_time) {
		this.submit_time = submit_time;
	}

}