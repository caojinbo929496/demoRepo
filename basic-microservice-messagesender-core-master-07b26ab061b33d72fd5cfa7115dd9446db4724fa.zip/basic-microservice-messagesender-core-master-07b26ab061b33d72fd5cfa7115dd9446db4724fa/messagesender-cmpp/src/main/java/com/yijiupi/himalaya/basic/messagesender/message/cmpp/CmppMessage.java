package com.yijiupi.himalaya.basic.messagesender.message.cmpp;

import com.yijiupi.himalaya.basic.messagesender.util.NetBits;

import java.io.IOException;
import java.io.Serializable;
import java.net.ProtocolException;
import java.util.ArrayList;
import java.util.List;


/**
 * 
 * cmpp消息包基类
 */
public abstract class CmppMessage implements CmppBody, Serializable {
	/**
	 * 消息命令id
	 */
	public static final int CID_CMPP_ACTIVETEST = 0x00000008;
	public static final int CID_CMPP_ACTIVETEST_RESP = 0x80000008;
	public static final int CID_CMPP_CANCEL = 0x00000007;
	public static final int CID_CMPP_CANCEL_RESP = 0x80000007;
	public static final int CID_CMPP_CONNECT = 0x00000001;
	public static final int CID_CMPP_CONNECT_RESP = 0x80000001;
	public static final int CID_CMPP_DELIVER = 0x00000005;
	public static final int CID_CMPP_DELIVER_RESP = 0x80000005;
	public static final int CID_CMPP_QUERY = 0x00000006;
	public static final int CID_CMPP_QUERY_RESP = 0x80000006;
	public static final int CID_CMPP_SUB_MULTI = 0x00000021;
	public static final int CID_CMPP_SUB_MULTI_RESP = 0x80000021;
	public static final int CID_CMPP_SUBMIT = 0x00000004;
	public static final int CID_CMPP_SUBMIT_RESP = 0x80000004;
	public static final int CID_CMPP_TERMINATE = 0x00000002;
	public static final int CID_CMPP_TERMINATE_RESP = 0x80000002;

	public static final String CMPP_ACTIVETEST = "CMPP_ACTIVETEST";
	public static final String CMPP_ACTIVETEST_RESP = "CMPP_ACTIVETEST_RESP";
	public static final String CMPP_CANCEL = "CMPP_CANCEL";
	public static final String CMPP_CANCEL_RESP = "CMPP_CANCEL_RESP";
	public static final String CMPP_CONNECT = "CMPP_CONNECT";
	public static final String CMPP_CONNECT_RESP = "CMPP_CONNECT_RESP";
	public static final String CMPP_DELIVER = "CMPP_DELIVER";
	public static final String CMPP_DELIVER_RESP = "CMPP_DELIVER_RESP";
	public static final String CMPP_QUERY = "CMPP_QUERY";
	public static final String CMPP_QUERY_RESP = "CMPP_QUERY_RESP";
	public static final String CMPP_SUB_MULTI = "CMPP_SUB_MULTI";
	public static final String CMPP_SUB_MULTI_RESP = "CMPP_SUB_MULTI_RESP";
	public static final String CMPP_SUBMIT = "CMPP_SUBMIT";
	public static final String CMPP_SUBMIT_RESP = "CMPP_SUBMIT_RESP";
	public static final String CMPP_TERMINATE = "CMPP_TERMINATE";
	public static final String CMPP_TERMINATE_RESP = "CMPP_TERMINATE_RESP";
	public static int CMPP_VERSION = 2;
	public static final int CMPP2_VERSION = 2;
	public static final String CMPP3_DELIVER = "CMPP3_DELIVER";
	public static final String CMPP3_DELIVER_RESP = "CMPP3_DELIVER_RESP";

	public static final String CMPP3_SUBMIT = "CMPP3_SUBMIT";

	public static final String CMPP3_SUBMIT_RESP = "CMPP3_SUBMIT_RESP";

	public final static String E_DATE_FORM_INVALID = "cmpp消息中日期格式无效！";

	// 定义好常用错误
	public final static String E_INVALID_COMMANDID = "cmpp消息命令错误！";
	public final static String E_INVALID_MSG = "不可识别的cmpp消息！";
	public final static String E_INVALID_MSG_HEAD = "cmpp消息头长度错误！";
	public final static String E_INVALID_SUBMITMSG_BODY = "submit消息头体错误！";
	public final static String E_MSG_FORM_INVALID = "cmpp消息格式无效！";
	public final static String E_MSG_LENGTH_INVALID = "cmpp消息长度无效！";
	// 错误码
	public static final int E_SUCCESS = 0;// 成功
	public static final int LEN_SSHEADER = 12; // 消息头长度
	public static final int MESSAGE_ACTIVE_RESP_BODY_LEN = 1;// 握手应答消息体长度
	// 消息体长度
	public static final int MESSAGE_CONNECT_BODY_LEN = 27;// 连接网关请求消息体长度
	public static final int MESSAGE_CONNECT_RESP_BODY_LEN_CMPP2 = 18;// 连接网关应答消息体长度
	public static final int MESSAGE_CONNECT_RESP_BODY_LEN_CMPP3 = 21;// 连接网关应答消息体长度
	public static final int MESSAGE_DELIVER_BODY_LEN_CMPP2 = 193;// cmpp2上行消息体长度
	public static final int MESSAGE_DELIVER_BODY_LEN_CMPP3 = 217;// cmpp3上行消息体长度
	public static final int MESSAGE_DELIVER_RESP_BODY_LEN_CMPP2 = 9;// 提交应答消息体长度
	public static final int MESSAGE_DELIVER_RESP_BODY_LEN_CMPP3 = 12;// 提交应答消息体长度
	// 消息编码类型
	public static final int MESSAGE_FMT_ASCII = 0;// ASCII串
	public static final int MESSAGE_FMT_BIT = 4;// 二进制信
	public static final int MESSAGE_FMT_CARD = 3;// 短信写卡
	public static final int MESSAGE_FMT_GB = 15;// 含GB汉字
	public static final int MESSAGE_FMT_UCS2 = 8;// UCS2编码
	public static final int MESSAGE_SUBMIT_BODY_LEN_CMPP2 = 147;// cmpp2提交消息体长度

	public static final int MESSAGE_SUBMIT_BODY_LEN_CMPP3 = 183;// cmpp3提交消息体长度
	public static final int MESSAGE_SUBMIT_RESP_BODY_LEN_CMPP2 = 9;// 提交应答消息体长度

	public static final int MESSAGE_SUBMIT_RESP_BODY_LEN_CMPP3 = 12;// 提交应答消息体长度
	public static final String PROTOCOL_CMPP2 = "cmpp2";
	private static int seqNum = 0;

	/**
	 * 获取发送消息序号
	 * 
	 * @return
	 */
	public synchronized static int createSeqNum() {
		if (seqNum >= 0x7fffffff) {
			seqNum = 1;
		}
		return (++seqNum);
	}

	public static int getCidCmppActivetestResp() {
		return CID_CMPP_ACTIVETEST_RESP;
	}

	/**
	 * 处理手机号的+86，如果手机号是以+86开头的，去掉前面的+86，返回后面11位
	 * 
	 * @param mobile
	 * @return
	 */
	protected static String handle86(String mobile) {
		if (mobile != null && mobile.startsWith("+86") && mobile.length() == 14)
			return mobile.substring(3);
		if (mobile != null && mobile.startsWith("86") && mobile.length() == 13)
			return mobile.substring(2);
		return mobile;
	}

	/**
	 * 短信内容按70个字符划分成多条内容,如果是按分条方式自动补'［1/3]'
	 * 
	 * @param message
	 *            短信内容
	 * @param messagelength
	 *            每条消息长度
	 * @param segmentation
	 *            是否自动补全索引
	 * @param isSign
	 *            是否需要预留签名位置
	 * @param signLength
	 *            签名长度
	 * @return
	 */
	public static List<String> msgSegmentation(String message, int messagelength, boolean segmentation, boolean isSign,
			int signLength) {
		List<String> msgs = new ArrayList<>();
		if (message.length() > 70) {
			int pages;
			if (isSign) {
				pages = (int) Math.ceil(((double) (message.length() + signLength)) / messagelength);
			} else {
				pages = (int) Math.ceil(((double) message.length()) / messagelength);
			}

			int beginIndex = 0;
			int endIndex;
			if (isSign) {
				endIndex = messagelength - signLength;
			} else {
				endIndex = messagelength;
			}
			for (int i = 1; i <= pages; i++) {
				if (segmentation) {// 分条
					if (i == pages) {
						msgs.add("[" + i + "/" + pages + "]" + message.substring(beginIndex));
					} else {
						msgs.add("[" + i + "/" + pages + "]" + message.substring(beginIndex, endIndex));
					}
				} else { // 长短信
					if (i == pages) {
						msgs.add(message.substring(beginIndex));
					} else {
						msgs.add(message.substring(beginIndex, endIndex));
					}
				}
				beginIndex = endIndex;
				endIndex = endIndex + messagelength;
			}
		} else {
			msgs.add(message);
		}

		return msgs;
	}

	// 消息头定义
	public int messageCommand = 0;// 消息命令字

	public int messageLength = 0;// 消息长度

	public int messageSequence = 0; // /消息序号

	public CmppMessage() {

	}

	public CmppMessage(byte[] headerBytes, byte[] bodyBytes) throws Exception {

	}

	/**
	 * 强制子类传递消息命令字
	 * 
	 * @param commandID
	 */
	protected CmppMessage(int commandID) {
		this.messageCommand = commandID;
	}

	protected CmppMessage(int commandID, int messageSequence) {
		this.messageCommand = commandID;
		this.messageSequence = messageSequence;
	}

	/**
	 * 解码消息头.
	 * 
	 * @param headerBytes
	 * @return: void
	 */
	public void decodeHeader(byte[] headerBytes) {
		messageLength = NetBits.getInt(headerBytes, 0);
		messageCommand = NetBits.getInt(headerBytes, 4);
		messageSequence = NetBits.getInt(headerBytes, 8);
	}

	/**
	 * 从字节数组中读取消息类的属性字段,如果字节数组无效,则会抛出Exception异常;
	 * 
	 * 强制子类实现
	 * 
	 *            字节数组
	 * @throws IOException
	 *             如果字节数组不合法，则会抛出此异常。
	 * @throws ProtocolException
	 *             协议解析错误，则会抛出此异常。
	 */
	public final void decodeMessage(byte[] data) throws Exception {
		messageLength = NetBits.getInt(data, 0);
		messageCommand = NetBits.getInt(data, 4);
		messageSequence = NetBits.getInt(data, 8);

		if (data.length > LEN_SSHEADER) {
			byte[] body = NetBits.getBytes(data, LEN_SSHEADER, data.length - LEN_SSHEADER);
			decodeBody(body);
		}
	}

	/**
	 * 编码消息头.
	 * 
	 * @return
	 * @return: byte[]
	 */
	public byte[] encodeHeader() {
		byte[] head = new byte[CmppMessage.LEN_SSHEADER];
		NetBits.putInt(head, 0, messageLength);
		NetBits.putInt(head, 4, messageCommand);
		NetBits.putInt(head, 8, messageSequence);
		return head;
	}

	/**
	 * 转换消息体为字节数组,发送消息时,客户端接口框架调用;
	 * 
	 * @return 消息转换后的字节数组
	 */
	public final byte[] encodeMessage() {
		byte[] body = encodeBody();
		if (body == null || body.length == 0) {
			messageLength = LEN_SSHEADER;
			return encodeHeader();
		}

		messageLength = LEN_SSHEADER + body.length;
		byte[] head = encodeHeader();
		byte[] data = new byte[messageLength];
		NetBits.putBytes(data, 0, head);
		NetBits.putBytes(data, LEN_SSHEADER, body);
		return data;
	}

	public int getMessageCommand() {
		return messageCommand;
	}

	public int getMessageLength() {
		return messageLength;
	}

	public int getMessageSequence() {
		return messageSequence;
	}

	public abstract String getName();

	public void setMessageCommand(int messageCommand) {
		this.messageCommand = messageCommand;
	}

	public void setMessageLength(int messageLength) {
		this.messageLength = messageLength;
	}

	public void setMessageSequence(int messageSequence) {
		this.messageSequence = messageSequence;
	}
}