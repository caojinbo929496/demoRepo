package com.yijiupi.himalaya.basic.messagesender.message.cmpp.codec;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;
import org.apache.mina.filter.codec.demux.MessageEncoder;

/**
 * CMPP协议编码器
 */
public class CMPPMessageEncoder implements MessageEncoder<CmppMessage> {

	public void encode(IoSession session, CmppMessage message,
			ProtocolEncoderOutput out) throws Exception {

		IoBuffer buf = IoBuffer.allocate(12, true);
		buf.setAutoExpand(true); // Enable auto-expand for easier encoding

		byte[] messageBytes = message.encodeMessage();
		buf.put(messageBytes);

		buf.flip();

		out.write(buf);
	}

}