package com.yijiupi.himalaya.basic.messagesender.link.client;

import com.yijiupi.himalaya.basic.messagesender.config.SingleClientConfig;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.ActiverTestRequest;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.ConnectRequest;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler.CMPPMessageHandler;
import com.yijiupi.himalaya.basic.messagesender.util.ConnectionStatus;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.transport.socket.nio.NioSocketConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

/**
 * Cmpp二级网关客户端消息处理.
 * 
 * @author: mxyong
 */
public class CmppClientIoHandlerAdapter extends IoHandlerAdapter {

	private static final Logger logger = LoggerFactory.getLogger(CmppClientIoHandlerAdapter.class);

	private SingleClientConfig singleClientConfig;
	private NioSocketConnector connector;
	private Map<String, ? extends CMPPMessageHandler> handlerMap;

	CmppClientIoHandlerAdapter(NioSocketConnector connector, SingleClientConfig singleClientConfig,
							   Map<String, ? extends CMPPMessageHandler> handlerMap) {
		this.connector = connector;
		this.singleClientConfig = singleClientConfig;
		this.handlerMap = handlerMap;
	}

	/**
	 * 发生异常.
	 */
	@Override
	public void exceptionCaught(IoSession session, Throwable cause) throws Exception {
		logger.error("与短信网关[" + session.getRemoteAddress() + "  " + session.getId() + "]连接发生异常！", cause);
		session.close(true);
	}

	/**
	 * 收到消息.
	 */
	@Override
	public void messageReceived(IoSession session, Object message) throws Exception {
		logger.debug(session.getId() + ": Received Message   " + message);
		if (message instanceof CmppMessage) {
			CmppMessage cmppMessage = (CmppMessage) message;
			CMPPMessageHandler messageHandler = handlerMap.get(cmppMessage.getName());
			if (null != messageHandler) {
				messageHandler.handle(session, cmppMessage);
			}
		}

		logger.debug("Successfuly received :" + message);
	}

	/**
	 * 发送消息.
	 */
	@Override
	public void messageSent(IoSession session, Object message) throws Exception {
		logger.debug("连接[" + session.getId() + "   状态:" + session.isConnected() + "]发送消息" + message + "成功！");
	}

	/**
	 * 链接关闭重连.
	 */
	@Override
	public void sessionClosed(IoSession session) throws Exception {
		String server = singleClientConfig.getServer();
		int port = singleClientConfig.getPort();
		logger.error("与短信网关[" + server + ":" + port + "]的连接关闭！");
		session.close(true);
		for (;;) {
			try {
				Thread.sleep(3000);
				ConnectFuture future = connector.connect(new InetSocketAddress(server, port));
				future.awaitUninterruptibly(30 * 1000);// 等待连接创建成功
				session = future.getSession();// 获取会话
				if (null != session && session.isConnected()) {
					logger.info("断线重连[" + server + ":" + port + "]成功");
					break;
				}
			} catch (Exception ex) {
				logger.info("重连服务器登录失败,3秒再连接一次:" + ex.getMessage());
			}
		}
	}

	/**
	 * 用来发送链路检测.
	 */
	@Override
	public void sessionIdle(IoSession session, IdleStatus status) throws Exception {
		int activerTestCount = 0;
		Object count = session.getAttribute(ConnectionStatus.ACTIVERTESTCOUNT);
		// 如果已经发送过三次链路检测包，且均未收到应答，则断开此链接
		if (count != null && count instanceof Integer) {
			activerTestCount = (Integer) count;
			if (activerTestCount >= 3) {
				String info = "与短信网关[" + session.getRemoteAddress() + "  " + session.getId() + "]的连接已经连续"
						+ activerTestCount + "次未到链路检测应答，断开此链接！";
				logger.info(info);
				session.close(true);
			}
		}
		activerTestCount++;

		if (session.getAttribute(ConnectionStatus.STATUS) == ConnectionStatus.STATUS_CONNECTED_LOGIN_SUCESS) {
			ActiverTestRequest atr = new ActiverTestRequest();
			session.write(atr);
			session.setAttribute(ConnectionStatus.ACTIVERTESTCOUNT, activerTestCount);
		} else {
			logger.info("与短信网关[" + session.getRemoteAddress() + "  " + session.getId() + "]的连接未登录，断开此连接！");
			session.close(true);
		}
	}

	/**
	 * 当客户端连接进入时,发送登录验证.
	 */
	@Override
	public void sessionOpened(IoSession session) throws Exception {
		logger.info("与短信网关[ip:" + singleClientConfig.getServer() + ",port:" + singleClientConfig.getPort() + "]连接打开，发送登录验证消息!");
		session.setAttribute(ConnectionStatus.STATUS, ConnectionStatus.STATUS_CONNECTED_LOGINING);
		session.setAttribute(ConnectionStatus.CONNECT_CONFIG, singleClientConfig);

		String sharedSecret = singleClientConfig.getSharedSecret();
		String sourceAddr = singleClientConfig.getSourceAddr();
		int version = 2;

		try {
			ConnectRequest request = new ConnectRequest(sourceAddr, sharedSecret, version);
			logger.info("连接[" + session.getRemoteAddress() + "   " + session.getId() + "]发送短信网关登录请求！");
			session.write(request);
		} catch (NoSuchAlgorithmException e) {
			logger.error("初始化登录请求协议时发生异常：" + e);
			session.close(true);
		}
	}

}
