package com.yijiupi.himalaya.basic.messagesender.link.client;

import com.yijiupi.himalaya.base.enums.MallAppType;
import com.yijiupi.himalaya.basic.messagesender.config.ClientConfig;
import com.yijiupi.himalaya.basic.messagesender.config.SingleClientConfig;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.SubmitRequest;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.codec.CMPPProtocolCodecFactory;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler.CMPPMessageHandler;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.core.session.IoSessionConfig;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.executor.ExecutorFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 短信网关客户端基类，提供连接初始化相关操作.
 *
 * @author: mxyong
 */
public class CmppClient {


	private static final Logger logger = LoggerFactory.getLogger(CmppClient.class);

	private NioSocketConnector connector;

	private final SingleClientConfig singleClientConfig;

	private MallAppType mallAppType;


	public CmppClient(ClientConfig clientConfig, Map<String, CMPPMessageHandler> handlerMap, MallAppType mallAppType) {
		singleClientConfig = new SingleClientConfig(clientConfig);
		this.mallAppType = mallAppType;
		logger.info("正在与短信网关[ip:" + singleClientConfig.getServer() + ",port:" + singleClientConfig.getPort() + ",类型:"+mallAppType.name()+"]建立连接.....");
		initConnector(clientConfig, handlerMap);
		new Thread(new ConnectThread()).start();
	}


	/**
	 * 连接短信网关的线程.
	 *
	 * @author: mxyong
	 * @date: 2016年7月14日 下午3:51:56
	 */
	class ConnectThread implements Runnable {
		@Override
		public void run() {
			for (int i = 0; i < singleClientConfig.getConnectNum(); i++) {
				while (true) {
					try {
						ConnectFuture future = connector.connect(new InetSocketAddress(singleClientConfig.getServer(), singleClientConfig.getPort()));
						future.awaitUninterruptibly(5 * 1000);// 等待连接创建
						IoSession session = future.getSession();// 获取会话
						if (null != session && session.isConnected()) {
							break;
						}
					} catch (Exception ex) {
						logger.info(mallAppType.name()+"连接服务器登录失败,3秒再连接一次:", ex);
						try {
							Thread.sleep(3000);
						} catch (InterruptedException e) {
							throw new RuntimeException(e);
						}
					}
				}
			}
		}
	}



	private int index = 0;




	/**
	 * 随机获取此客户端的一个session.
	 */
	private IoSession getSession() {
		Map<Long, IoSession> sessionMap = connector.getManagedSessions();
		if (null == sessionMap || sessionMap.size() == 0) {
			return null;
		}
		List<IoSession> sessions = new ArrayList<>(sessionMap.values());
		IoSession session = null;
		while (true) {
			index++;

			session = sessions.get(index % sessions.size());
			if (session.isConnected()) {
				return session;
			}
		}
	}

	/**
	 * 初始化客户端.
	 *
	 * @return: void
	 */
	public void init() {

	}

	private void initConnector(ClientConfig clientConfig, Map<String, ? extends CMPPMessageHandler> handlerMap) {
		connector = new NioSocketConnector();

		connector.getFilterChain().addLast("exceutor", new ExecutorFilter());
		connector.setConnectTimeoutMillis(30 * 1000);
		IoSessionConfig sessionConfig = connector.getSessionConfig();
		sessionConfig.setIdleTime(IdleStatus.BOTH_IDLE, 30);

		sessionConfig.setWriteTimeout(10);
		connector.getFilterChain().addLast("codec", new ProtocolCodecFilter(new CMPPProtocolCodecFactory()));
		connector.setHandler(new CmppClientIoHandlerAdapter(connector, singleClientConfig, handlerMap));
	}

	/**
	 * 发送消息.
	 *
	 * @param mobile
	 * @param content
	 * @return: void
	 */
	public void sendMessage(String mobile, String content) {
		List<SubmitRequest> submitRequests = SubmitRequest.convert(mobile, content, "HELP",
				singleClientConfig.getSourceAddr(), singleClientConfig.getSrcId(), "01", "000000", 0, true, false, 0);
		IoSession sessions = getSession();

		for (SubmitRequest submitRequest : submitRequests) {
			sessions.write(submitRequest);
		}
	}

}