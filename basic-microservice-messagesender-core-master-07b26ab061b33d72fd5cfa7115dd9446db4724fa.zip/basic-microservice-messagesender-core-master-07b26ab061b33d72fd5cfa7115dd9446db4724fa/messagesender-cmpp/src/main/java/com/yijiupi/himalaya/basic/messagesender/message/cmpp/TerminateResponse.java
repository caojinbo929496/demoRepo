
package com.yijiupi.himalaya.basic.messagesender.message.cmpp;

/**
 * 拆除网关连接应答消息
 * 
 */
public class TerminateResponse extends CmppMessage {
	public TerminateResponse() {

	}

	public TerminateResponse(int messageSequence) {
		super(CID_CMPP_TERMINATE_RESP, messageSequence);
	}

	@Override
	public void decodeBody(byte[] body) throws Exception {

	}

	@Override
	public byte[] encodeBody() {
		return null;
	}

	@Override
	public String getName() {
		return CMPP_TERMINATE_RESP;
	}

}