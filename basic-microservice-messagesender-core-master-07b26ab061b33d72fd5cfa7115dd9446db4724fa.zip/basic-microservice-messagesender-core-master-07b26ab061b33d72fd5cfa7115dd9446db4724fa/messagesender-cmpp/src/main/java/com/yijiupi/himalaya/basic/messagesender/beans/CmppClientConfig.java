package com.yijiupi.himalaya.basic.messagesender.beans;


import com.yijiupi.himalaya.base.enums.MallAppType;
import com.yijiupi.himalaya.basic.messagesender.common.ThreadLocalMallAppType;
import com.yijiupi.himalaya.basic.messagesender.config.ClientConfig;
import com.yijiupi.himalaya.basic.messagesender.link.client.CmppClient;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler.CMPPMessageHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class CmppClientConfig {

    @Bean
    public Map<MallAppType, CmppClient> initClientConfig(ClientConfig clientConfig, Map<String, CMPPMessageHandler> handlerMap) {
        MallAppType[] mallAppTypes = MallAppType.values();
        Map<MallAppType, CmppClient> mallAppTypeClientConfigMap = new HashMap<>(mallAppTypes.length);
        for (MallAppType mallAppType : mallAppTypes) {
            ThreadLocalMallAppType.init(mallAppType);
            mallAppTypeClientConfigMap.put(mallAppType, new CmppClient(clientConfig, handlerMap, mallAppType));
        }
        return mallAppTypeClientConfigMap;
    }
}
