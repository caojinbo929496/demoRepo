package com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * 拆除链接应答处理.
 * 
 * @author: mxyong
 */
@Component(CmppMessage.CMPP_TERMINATE_RESP)
public class TerminateResponseHandler implements CMPPMessageHandler {
	private static final Logger logger = LoggerFactory.getLogger(TerminateResponseHandler.class);

	@Override
	public void handle(IoSession session, CmppMessage message) {
		logger.debug("收到断开连接应答消息.");
		session.close(true);
	}
}
