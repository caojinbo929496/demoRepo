package com.yijiupi.himalaya.basic.messagesender.util;


import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

/**
 * 
 * 字节数组工具类
 */
public class ByteUtility {

	private final static char[] Digit = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E',
			'F' };
	public static final String GBK_DCS_TYPE = "gbk";
	public static final int SM_DCS_ASC = 0;
	public static final int SM_DCS_ASC_FREERECV = 16;
	public static final int SM_DCS_GBK = 15;
	public static final int SM_DCS_UNICODE = 8;
	public static final int SM_DCS_UNICODE_FREERECV = 24;

	public static final String UTF_DCS_TYPE = "UTF-16BE";

	public static String byteHex(byte ib) {
		char[] ob = new char[2];
		ob[0] = Digit[(ib >>> 4) & 0x0f];
		ob[1] = Digit[ib & 0x0f];
		return new String(ob);
	}

	public static final int bytesToByte(byte bytes[]) {
		return bytes[0] & 0xff;
	}

	public static final int bytesToInt(byte bytes[]) {
		return (bytes[3] & 0xff) + ((bytes[2] & 0xff) << 8) + ((bytes[1] & 0xff) << 16) + ((bytes[0] & 0xff) << 24);
	}

	public static long bytesToLong(byte abyte0[]) {
		return ((long) abyte0[0] << 56 & 0xFF00000000000000L) | ((long) abyte0[1] << 48 & 0xFF000000000000L)
				| ((long) abyte0[2] << 40 & 0xFF0000000000L) | ((long) abyte0[3] << 32 & 0xFF00000000L)
				| ((long) abyte0[4] << 24 & 0xFF000000L) | ((long) abyte0[5] << 16 & 0xFF0000L)
				| ((long) abyte0[6] << 8 & 0xFF00L) | (abyte0[7] & 0xFFL);
	}

	public static String bytesToStr(byte bytes[]) {
		return new String(bytes).trim();
	}

	public static String bytesToStr(byte bytes[], int offset, int length) {
		return new String(bytes, offset, length).trim();
	}

	public static String bytesToStr(byte bytes[], String dcs) {
		try {
			return new String(bytes, dcs).trim();
		} catch (Exception ex) {
			return null;
		}
	}

	public static byte[] byteToBytes(int i) {
		byte[] abyte = new byte[1];
		abyte[0] = (byte) (i & 0xFF);
		return abyte;
	}

	public static String dataFormat(byte[] context, int dcs) throws UnsupportedEncodingException {
		if (dcs == SM_DCS_UNICODE)
			return new String(context, UTF_DCS_TYPE);
		else if (dcs == SM_DCS_GBK)
			return new String(context, GBK_DCS_TYPE);
		else
			return new String(context);
	}

	public static byte[] dataFormat(String contextStr, int dcs) throws UnsupportedEncodingException {
		if (dcs == SM_DCS_UNICODE || dcs == SM_DCS_UNICODE_FREERECV)
			return contextStr.getBytes(UTF_DCS_TYPE);
		else if (dcs == SM_DCS_GBK)
			return contextStr.getBytes(GBK_DCS_TYPE);
		else {
			byte[] code = contextStr.getBytes("ISO-8859-1");
			return code;
		}
	}

	public static final int getIntFromBytes(byte[] b, int offset, int len) throws IOException {
		int num = 0;
		int sw = 8 * (len - 1);

		for (int loop = 0; loop < len; loop++) {
			num |= (b[offset + loop] & 0x00ff) << sw;
			sw -= 8;
		}

		return num;
	}

	/**
	 * 消息内容解码（转换为系统默认编码）
	 * 
	 * @param content
	 * @param fmt
	 * @return
	 */
	public static byte[] getMsgContent(byte[] content, int fmt) {
		byte[] msg = null;
		if (content == null || content.length == 0)
			return null;

		try {
			if (fmt == CmppMessage.MESSAGE_FMT_UCS2)
				msg = new String(content, "UTF-16BE").getBytes();
			else if (fmt == CmppMessage.MESSAGE_FMT_GB)
				msg = new String(content, "GBK").getBytes();
			else
				msg = new String(content).getBytes();
		} catch (UnsupportedEncodingException e) {

		}

		return msg;
	}

	/**
	 * 消息内容编码(根据不同编码类型进行转换)
	 * 
	 * @param content
	 * @param fmt
	 * @return
	 */
	public static byte[] getMsgContent(String content, int fmt) {
		byte[] msg = null;
		try {
			if (fmt == CmppMessage.MESSAGE_FMT_UCS2)
				msg = content.getBytes("UTF-16BE");
			else if (fmt == CmppMessage.MESSAGE_FMT_GB)
				msg = content.getBytes("GBK");
			else
				msg = content.getBytes();
		} catch (UnsupportedEncodingException e) {

		}
		return msg;
	}

	public static String getMsgContentString(byte[] content, int fmt) {
		String msg = null;
		if (content == null || content.length == 0)
			return null;

		try {
			if (fmt == CmppMessage.MESSAGE_FMT_UCS2)
				msg = new String(content, "UTF-16BE");
			else if (fmt == CmppMessage.MESSAGE_FMT_GB)
				msg = new String(content, "GBK");
			else
				msg = new String(content);
		} catch (UnsupportedEncodingException e) {

		}

		return msg;
	}

	public static byte[] intToBytes(int i) {
		byte[] abyte = new byte[4];
		abyte[3] = (byte) (i & 0xFF);
		abyte[2] = (byte) ((i >> 8) & 0xFF);
		abyte[1] = (byte) ((i >> 16) & 0xFF);
		abyte[0] = (byte) ((i >> 24) & 0xFF);
		return abyte;
	}

	public static final byte[] longToBytes(long l) {
		byte abyte0[] = new byte[8];
		abyte0[7] = (byte) (int) (255L & l);
		abyte0[6] = (byte) (int) ((65280L & l) >> 8);
		abyte0[5] = (byte) (int) ((0xff0000L & l) >> 16);
		abyte0[4] = (byte) (int) ((0xffffffffff000000L & l) >> 24);
		int i = (int) (l >> 32);
		abyte0[3] = (byte) (0xff & i);
		abyte0[2] = (byte) ((0xff00 & i) >> 8);
		abyte0[1] = (byte) ((0xff0000 & i) >> 16);
		abyte0[0] = (byte) ((0xff000000 & i) >> 24);
		return abyte0;
	}

	public static void printBytes(byte[] bytes) {
		String info = "";
		for (int i = 0; i < bytes.length; i++)
			info += byteHex(bytes[i]) + " ";
	}

	/**
	 * 拷贝定长字符串到字节数组中，不足右补零
	 * 
	 * @param s
	 * @param b
	 * @param offset
	 * @param len
	 */
	public static final void putFixedStringToBytes(byte[] b, int offset, String s, int len) {
		if (s == null)
			s = "";

		byte data[] = new byte[len];
		byte[] tmp = new byte[len];
		data = s.getBytes();
		if (null == data)
			data = new byte[0];

		if (data.length >= len) {
			System.arraycopy(data, 0, tmp, 0, len);
		} else {
			System.arraycopy(data, 0, tmp, 0, data.length);
			for (int i = data.length; i < len; i++)
				tmp[i] = 0;
		}
		System.arraycopy(tmp, 0, b, offset, tmp.length);
	}

	public static final void putIntToBytes(byte[] b, int off, int num, int len) {
		byte[] b1 = new byte[len];
		int sw = ((len - 1) * 8);
		int mask = (0xff << sw);

		for (int l = 0; l < len; l++) {
			b1[l] = (byte) ((num & mask) >>> sw);
			sw -= 8;
			mask >>>= 8;
		}

		System.arraycopy(b1, 0, b, off, len);
	}

	private ByteUtility() {
	}
}