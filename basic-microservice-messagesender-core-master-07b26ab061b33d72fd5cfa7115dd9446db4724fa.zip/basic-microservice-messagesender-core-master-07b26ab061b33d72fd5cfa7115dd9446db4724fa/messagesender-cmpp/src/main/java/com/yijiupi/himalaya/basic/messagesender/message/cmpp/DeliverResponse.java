
package com.yijiupi.himalaya.basic.messagesender.message.cmpp;


import com.yijiupi.himalaya.basic.messagesender.util.ByteUtility;
import com.yijiupi.himalaya.basic.messagesender.util.NetBits;

/**
 * 上行消息应答
 */

public class DeliverResponse extends CmppMessage {
	private String msg_Id;
	private int result = 0;

	public DeliverResponse() {

	}

	public DeliverResponse(int messageSequence) {
		super(CID_CMPP_DELIVER_RESP, messageSequence);
	}

	@Override
	public void decodeBody(byte[] body) throws Exception {
		int index = 0;

		msg_Id = Long.toUnsignedString(NetBits.getLong(body, index));
		index += 8;
		result = ByteUtility.getIntFromBytes(body, index, 1);
	}

	@Override
	public byte[] encodeBody() {

		int index = 0;
		byte[] msg = new byte[MESSAGE_DELIVER_RESP_BODY_LEN_CMPP2];

		index = 0;
		NetBits.putLong(msg, index, Long.parseUnsignedLong(msg_Id));
		index += 8;
		ByteUtility.putIntToBytes(msg, index, result, 1);

		return msg;
	}

	public String getMsg_Id() {
		return msg_Id;
	}

	@Override
	public String getName() {
		return CMPP_DELIVER_RESP;
	}

	public int getResult() {
		return result;
	}

	public void setMsg_Id(String msg_Id) {
		this.msg_Id = msg_Id;
	}

	public void setResult(int result) {
		this.result = result;
	}

}