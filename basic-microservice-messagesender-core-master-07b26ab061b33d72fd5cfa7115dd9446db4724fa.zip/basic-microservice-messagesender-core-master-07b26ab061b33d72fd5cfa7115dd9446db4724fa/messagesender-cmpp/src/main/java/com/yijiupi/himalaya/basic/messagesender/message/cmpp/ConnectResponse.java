package com.yijiupi.himalaya.basic.messagesender.message.cmpp;


import com.yijiupi.himalaya.basic.messagesender.util.ByteUtility;
import com.yijiupi.himalaya.basic.messagesender.util.NetBits;

/**
 * 
 * 网关连接应答消息
 */
public class ConnectResponse extends CmppMessage {
	private String authenticatorISMG;
	private int status;
	private int version;

	public ConnectResponse() {
	}

	public ConnectResponse(int messageSequence) {
		super(CID_CMPP_CONNECT_RESP, messageSequence);
	}

	@Override
	public void decodeBody(byte[] body) throws Exception {
		if (!(body.length == MESSAGE_CONNECT_RESP_BODY_LEN_CMPP2
				|| body.length == MESSAGE_CONNECT_RESP_BODY_LEN_CMPP3)) {
			throw new Exception(CmppMessage.E_INVALID_MSG_HEAD);
		}

		int index = 0;

		if (body.length == MESSAGE_CONNECT_RESP_BODY_LEN_CMPP2) {
			status = ByteUtility.getIntFromBytes(body, index, 1);

			index += 1;
		} else {
			status = ByteUtility.getIntFromBytes(body, index, 4);

			index += 4;
		}

		authenticatorISMG = NetBits.getString(body, index, 16);
		index += 16;

		version = ByteUtility.getIntFromBytes(body, index, 1);

		CMPP_VERSION = version;// 记录cmpp版本号
	}

	@Override
	public byte[] encodeBody() {
		int index = 0;
		byte[] msg = new byte[MESSAGE_CONNECT_RESP_BODY_LEN_CMPP2];
		ByteUtility.putIntToBytes(msg, index, status, 1);
		index += 1;
		NetBits.putString(msg, index, authenticatorISMG, 16);
		index += 16;
		ByteUtility.putIntToBytes(msg, index, version, 1);

		return msg;
	}

	public String getAuthenticatorISMG() {
		return (authenticatorISMG);
	}

	@Override
	public String getName() {
		return CMPP_CONNECT_RESP;
	}

	public int getStatus() {
		return status;
	}

	public int getVersion() {
		return version;
	}

	public void setAuthenticatorISMG(String authISMG) {
		this.authenticatorISMG = authISMG;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public void setVersion(int version) {
		this.version = version;
	}

}