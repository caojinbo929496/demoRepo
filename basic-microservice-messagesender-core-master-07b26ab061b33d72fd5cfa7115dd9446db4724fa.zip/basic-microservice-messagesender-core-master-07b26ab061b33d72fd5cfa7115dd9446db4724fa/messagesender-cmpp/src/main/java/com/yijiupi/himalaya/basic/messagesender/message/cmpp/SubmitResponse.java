package com.yijiupi.himalaya.basic.messagesender.message.cmpp;


import com.yijiupi.himalaya.basic.messagesender.util.ByteUtility;
import com.yijiupi.himalaya.basic.messagesender.util.NetBits;

/**
 * 
 * 提交短信应答消息
 */
public class SubmitResponse extends CmppMessage {
	private String msg_Id;
	private int status = 0;

	public SubmitResponse() {

	}

	public SubmitResponse(String msg_Id, int status, int messageSequence) {
		super(CID_CMPP_SUBMIT_RESP, messageSequence);
		this.msg_Id = msg_Id;
		this.status = status;
	}

	@Override
	public void decodeBody(byte[] body) throws Exception {
		if (body.length != MESSAGE_SUBMIT_RESP_BODY_LEN_CMPP2)
			throw new Exception(CmppMessage.E_INVALID_SUBMITMSG_BODY);

		int index = 0;

		msg_Id = Long.toUnsignedString(NetBits.getLong(body, index));

		index += 8;

		status = ByteUtility.getIntFromBytes(body, index, 1);
	}

	@Override
	public byte[] encodeBody() {
		int index = 0;
		byte[] msg = new byte[MESSAGE_SUBMIT_RESP_BODY_LEN_CMPP2];

		NetBits.putLong(msg, index, Long.parseUnsignedLong(msg_Id));
		index += 8;

		ByteUtility.putIntToBytes(msg, index, status, 1);

		return msg;
	}

	public String getMsg_Id() {
		return msg_Id;
	}

	@Override
	public String getName() {
		return CMPP_SUBMIT_RESP;
	}

	public int getStatus() {
		return status;
	}

	public void setMsg_Id(String msg_Id) {
		this.msg_Id = msg_Id;
	}

	public void setStatus(int status) {
		this.status = status;
	}

}