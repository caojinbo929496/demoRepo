package com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import org.apache.mina.core.session.IoSession;


/**
 * 所有消息处理接口.
 * 
 * @author: mxyong
 */
public interface CMPPMessageHandler {
	/**
	 * 消息处理接口.
	 * 
	 * @param session
	 * @param message
	 * @return: void
	 */
	void handle(IoSession session, CmppMessage message);
}
