
package com.yijiupi.himalaya.basic.messagesender.message.cmpp;

/**
 * 拆除网关连接请求消息
 * 
 */
public class TerminateRequest extends CmppMessage {

	public TerminateRequest() {
	}

	public TerminateRequest(int messageSequence) {
		super(CID_CMPP_TERMINATE, messageSequence);
	}

	@Override
	public void decodeBody(byte[] body) throws Exception {

	}

	@Override
	public byte[] encodeBody() {
		return null;
	}

	@Override
	public String getName() {
		return CMPP_TERMINATE;
	}

}