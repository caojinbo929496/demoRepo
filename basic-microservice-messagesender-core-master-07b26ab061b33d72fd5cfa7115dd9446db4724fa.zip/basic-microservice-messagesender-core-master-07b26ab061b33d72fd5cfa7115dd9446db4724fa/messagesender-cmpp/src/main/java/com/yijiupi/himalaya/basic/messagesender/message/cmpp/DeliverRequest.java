package com.yijiupi.himalaya.basic.messagesender.message.cmpp;

import com.yijiupi.himalaya.basic.messagesender.util.ByteUtility;
import com.yijiupi.himalaya.basic.messagesender.util.NetBits;

import java.io.IOException;


/**
 * 上行消息请求
 */
public class DeliverRequest extends CmppMessage {
	public static final int DELIVER_IS_STATUSREPORT = 1;
	public static final int DELIVER_NOT_IS_STATUSREPORT = 0;
	private String Dest_Id = ""; // 目的号码 SP的服务代码
	private Object id;
	private boolean isLongSMS = false;// 是否长短信
	private boolean isStatusReport = false;// 该上行是否为状态报告
	private byte[] msg_Content = null;// 信息内容
	private int msg_Fmt = 0;// 信息格式
	private String msg_Id;// 信息标识
	private int msg_Length = 0;// 信息长度(Msg_Fmt值为0时：<160个字节；其它<=140个字节)
	private String msgContent;
	private int pk_Number = 1;// 长短信的信息序号
	private int pk_Total = 1;// 长短信折分总条数

	private int registered_Delivery = 0;// 是否为状态报告
	private String reserved = "";// 保留项
	private String service_Id = "";// 业务类型
	private String src_Terminal_Id = "";// 源终端MSISDN号码（状态报告时填为CMPP_SUBMIT消息的目的终端号码）

	private StatusReport statusRep = null;
	private int tp_PId = 0;// GSM协议类型

	private int tp_Udhi = 0;// GSM协议类型

	public DeliverRequest() {
		super(CID_CMPP_DELIVER);
	}

	@Override
	public void decodeBody(byte[] body) throws Exception {
		int index = 0;

		msg_Id = Long.toUnsignedString(NetBits.getLong(body, index));
		index += 8;

		Dest_Id = NetBits.getString(body, index, 21);
		index += 21;

		service_Id = NetBits.getString(body, index, 10);
		index += 10;
		tp_PId = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		tp_Udhi = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		msg_Fmt = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		src_Terminal_Id = NetBits.getString(body, index, 21);
		src_Terminal_Id = handle86(src_Terminal_Id);
		index += 21;

		registered_Delivery = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;

		msg_Length = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;

		msg_Content = NetBits.getBytes(body, index, msg_Length);

		// 解析状态报告
		if (registered_Delivery == DELIVER_IS_STATUSREPORT) {
			readStatusReport(msg_Content);
		}
		// 解析普通内容
		else {
			byte[] content = NetBits.getBytes(body, index, msg_Length);
			// 上行长短信的解码
			if (tp_Udhi == 1 && msg_Fmt == 8 && content.length > 6) {
				byte length = content[0];
				byte secondByte = content[1];
				byte threeByte = content[2];
				if ((length == 5 && secondByte == 0 && threeByte == 3)
						|| (length == 6 && secondByte == 8 && threeByte == 4)) {
					if (content.length > length + 1) {
						byte[] pkBytes = new byte[length + 1];
						System.arraycopy(content, 0, pkBytes, 0, length + 1);
						pk_Number = pkBytes[length];
						pk_Total = pkBytes[length - 1];
						isLongSMS = true;

						byte[] newContent = new byte[content.length - length - 1];
						System.arraycopy(content, length + 1, newContent, 0, newContent.length);

						msgContent = ByteUtility.getMsgContentString(newContent, msg_Fmt);
					}
				} else {
					msgContent = ByteUtility.getMsgContentString(content, msg_Fmt);
				}
			} else { // 普通上行
				msgContent = ByteUtility.getMsgContentString(content, msg_Fmt);
			}
		}

		index += msg_Length;

		reserved = NetBits.getString(body, index, 8);

	}

	@Override
	public byte[] encodeBody() {
		int index = 0;
		byte[] msg = new byte[MESSAGE_DELIVER_BODY_LEN_CMPP2 + msg_Length];

		NetBits.putLong(msg, index, Long.parseUnsignedLong(msg_Id));
		index += 8;
		ByteUtility.putFixedStringToBytes(msg, index, Dest_Id, 21);
		index += 21;
		ByteUtility.putFixedStringToBytes(msg, index, service_Id, 10);
		index += 10;
		ByteUtility.putIntToBytes(msg, index, tp_PId, 1);
		index += 1;
		ByteUtility.putIntToBytes(msg, index, tp_Udhi, 1);
		index += 1;
		ByteUtility.putIntToBytes(msg, index, msg_Fmt, 1);
		index += 1;
		ByteUtility.putFixedStringToBytes(msg, index, src_Terminal_Id, 21);
		index += 21;
		ByteUtility.putIntToBytes(msg, index, registered_Delivery, 1);
		index += 1;
		ByteUtility.putIntToBytes(msg, index, msg_Length, 1);
		index += 1;
		if (registered_Delivery == 1) {
			NetBits.putBytes(msg, index, encodeStatusReport());
		} else {
			NetBits.putBytes(msg, index, msg_Content);
		}
		index += msg_Length;

		ByteUtility.putFixedStringToBytes(msg, index, reserved, 8);

		return msg;
	}

	/**
	 * 对状态报告进行编码.
	 * 
	 * @return
	 * @return: byte[]
	 */
	private byte[] encodeStatusReport() {
		byte[] msg = new byte[60];
		int index = 0;
		NetBits.putLong(msg, index, Long.parseUnsignedLong(statusRep.getMsg_Id()));
		index += 8;
		ByteUtility.putFixedStringToBytes(msg, index, statusRep.getStat(), 7);
		index += 7;
		ByteUtility.putFixedStringToBytes(msg, index, statusRep.getSubmit_time(), 10);
		index += 10;
		ByteUtility.putFixedStringToBytes(msg, index, statusRep.getDone_time(), 10);
		index += 10;
		ByteUtility.putFixedStringToBytes(msg, index, statusRep.getDest_terminal_Id(), 21);
		index += 21;
		NetBits.putInt(msg, index, statusRep.getSms_sequence());
		return msg;
	}

	public String getDest_Id() {
		return Dest_Id;
	}

	public Object getId() {
		return id;
	}

	public String getLinkID() {
		return null;
	}

	public byte[] getMsg_Content() {
		return msg_Content;
	}

	public int getMsg_Fmt() {
		return msg_Fmt;
	}

	public String getMsg_Id() {
		return msg_Id;
	}

	public int getMsg_Length() {
		return msg_Length;
	}

	public String getMsgContent() {
		return msgContent;
	}

	@Override
	public String getName() {
		return CMPP_DELIVER;
	}

	public int getPk_Number() {
		return pk_Number;
	}

	public int getPk_Total() {
		return pk_Total;
	}

	public int getRegistered_Delivery() {
		return registered_Delivery;
	}

	public String getReserved() {
		return reserved;
	}

	public CmppMessage getResponse() {
		DeliverResponse resp = new DeliverResponse(getMessageSequence());
		resp.setMsg_Id(getMsg_Id());
		resp.setResult(0);
		return resp;
	}

	public String getService_Id() {
		return service_Id;
	}

	public String getSrc_Terminal_Id() {
		return src_Terminal_Id;
	}

	public StatusReport getStatusRep() {
		return statusRep;
	}

	public int getTp_PId() {
		return tp_PId;
	}

	public int getTp_Udhi() {
		return tp_Udhi;
	}

	public boolean isLongSMS() {
		return isLongSMS;
	}

	public boolean isStatusReport() {
		return isStatusReport;
	}

	/** 读取状态报告* */
	private void readStatusReport(byte[] content) throws IOException {
		int index = 0;
		String msg_Id;
		String stat = "";
		String submit_Time = "";
		String done_Time = "";
		String dest_Terminal_Id = "";
		int smsc_Sequence = 0;

		msg_Id = Long.toUnsignedString(NetBits.getLong(content, index));
		index += 8;
		stat = NetBits.getString(content, index, 7);
		index += 7;
		submit_Time = NetBits.getString(content, index, 10);
		index += 10;
		done_Time = NetBits.getString(content, index, 10);
		index += 10;
		dest_Terminal_Id = NetBits.getString(content, index, 21);
		dest_Terminal_Id = handle86(dest_Terminal_Id);
		index += 21;
		smsc_Sequence = ByteUtility.getIntFromBytes(content, index, 4);

		statusRep = new StatusReport();
		statusRep.setMsg_Id(msg_Id);
		statusRep.setStat(stat);
		statusRep.setSubmit_time(submit_Time);
		statusRep.setDone_time(done_Time);
		statusRep.setDest_terminal_Id(dest_Terminal_Id);
		statusRep.setSrc_Id(Dest_Id);
		statusRep.setSms_sequence(smsc_Sequence);
		isStatusReport = true;
	}

	public void setDest_Id(String dest_Id) {
		Dest_Id = dest_Id;
	}

	public void setId(Object id) {
		this.id = id;
	}

	public void setLongSMS(boolean isLongSMS) {
		this.isLongSMS = isLongSMS;
	}

	public void setMsg_Content(byte[] msg_Content) {
		this.msg_Content = msg_Content;
	}

	public void setMsg_Fmt(int msg_Fmt) {
		this.msg_Fmt = msg_Fmt;
	}

	public void setMsg_Id(String msg_Id) {
		this.msg_Id = msg_Id;
	}

	public void setMsg_Length(int msg_Length) {
		this.msg_Length = msg_Length;
	}

	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}

	public void setPk_Number(int pk_Number) {
		this.pk_Number = pk_Number;
	}

	public void setPk_Total(int pk_Total) {
		this.pk_Total = pk_Total;
	}

	public void setRegistered_Delivery(int registered_Delivery) {
		this.registered_Delivery = registered_Delivery;
	}

	public void setReserved(String reserved) {
		this.reserved = reserved;
	}

	public void setService_Id(String service_Id) {
		this.service_Id = service_Id;
	}

	public void setSrc_Terminal_Id(String src_Terminal_Id) {
		this.src_Terminal_Id = src_Terminal_Id;
	}

	public void setStatusRep(StatusReport statusRep) {
		this.statusRep = statusRep;
	}

	public void setStatusReport(boolean isStatusReport) {
		this.isStatusReport = isStatusReport;
	}

	public void setTp_PId(int tp_PId) {
		this.tp_PId = tp_PId;
	}

	public void setTp_Udhi(int tp_Udhi) {
		this.tp_Udhi = tp_Udhi;
	}

}