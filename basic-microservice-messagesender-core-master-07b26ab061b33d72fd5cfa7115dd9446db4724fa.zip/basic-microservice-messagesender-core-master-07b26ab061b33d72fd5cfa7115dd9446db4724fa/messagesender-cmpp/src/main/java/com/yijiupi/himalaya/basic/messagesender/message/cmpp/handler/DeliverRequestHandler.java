package com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.DeliverRequest;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * 上行消息处理.
 * 
 * @author: mxyong
 */
@Component(CmppMessage.CMPP_DELIVER)
public class DeliverRequestHandler implements CMPPMessageHandler {
	private static final Logger logger = LoggerFactory.getLogger(DeliverRequestHandler.class);

	@Override
	public void handle(IoSession session, CmppMessage message) {
		logger.debug("收到上行.");
		DeliverRequest deliverRequest = (DeliverRequest) message;
		session.write(deliverRequest.getResponse());

		// 不处理上行.

	}

}
