package com.yijiupi.himalaya.basic.messagesender.message.cmpp.codec;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import org.apache.mina.filter.codec.demux.DemuxingProtocolCodecFactory;


/**
 * 协议编解码器工厂
 */
public class CMPPProtocolCodecFactory extends DemuxingProtocolCodecFactory {

	public CMPPProtocolCodecFactory() {
		super.addMessageDecoder(CMPPMessageDecoder.class);
		super.addMessageEncoder(CmppMessage.class, CMPPMessageEncoder.class);
	}
}