
package com.yijiupi.himalaya.basic.messagesender.message.cmpp;

/**
 * 
 * 链路检测请求
 */
public class ActiverTestRequest extends CmppMessage {
	public ActiverTestRequest() {
		super(CmppMessage.CID_CMPP_ACTIVETEST, createSeqNum());
	}

	@Override
	public void decodeBody(byte[] body) {

	}

	@Override
	public byte[] encodeBody() {
		return null;
	}

	@Override
	public String getName() {
		return CMPP_ACTIVETEST;
	}
}
