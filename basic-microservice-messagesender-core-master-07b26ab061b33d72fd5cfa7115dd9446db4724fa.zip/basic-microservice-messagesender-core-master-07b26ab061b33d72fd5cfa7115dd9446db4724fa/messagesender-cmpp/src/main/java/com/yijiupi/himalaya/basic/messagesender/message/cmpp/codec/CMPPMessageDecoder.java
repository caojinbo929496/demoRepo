package com.yijiupi.himalaya.basic.messagesender.message.cmpp.codec;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.*;
import com.yijiupi.himalaya.basic.messagesender.util.NetBits;
import org.apache.log4j.Logger;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;
import org.apache.mina.filter.codec.demux.MessageDecoder;
import org.apache.mina.filter.codec.demux.MessageDecoderResult;

/**
 * CMPP协议解码器
 */
public class CMPPMessageDecoder implements MessageDecoder {
	private static Logger logger = Logger.getLogger(CMPPMessageDecoder.class);

	@Override
	public MessageDecoderResult decodable(IoSession session, IoBuffer in) {
		if (in.remaining() < CmppMessage.LEN_SSHEADER) {
			return MessageDecoderResult.NEED_DATA;
		}
		byte[] headerBytes = new byte[CmppMessage.LEN_SSHEADER];
		in.get(headerBytes);

		int messageLength = NetBits.getInt(headerBytes, 0);
		if (in.remaining() < messageLength - CmppMessage.LEN_SSHEADER)
			return MessageDecoderResult.NEED_DATA;

		int messageCommand = NetBits.getInt(headerBytes, 4);

		if (messageCommand == CmppMessage.CID_CMPP_CONNECT || messageCommand == CmppMessage.CID_CMPP_CONNECT_RESP
				|| messageCommand == CmppMessage.CID_CMPP_ACTIVETEST
				|| messageCommand == CmppMessage.CID_CMPP_ACTIVETEST_RESP
				|| messageCommand == CmppMessage.CID_CMPP_TERMINATE
				|| messageCommand == CmppMessage.CID_CMPP_TERMINATE_RESP
				|| messageCommand == CmppMessage.CID_CMPP_SUBMIT || messageCommand == CmppMessage.CID_CMPP_SUBMIT_RESP
				|| messageCommand == CmppMessage.CID_CMPP_DELIVER
				|| messageCommand == CmppMessage.CID_CMPP_DELIVER_RESP) {
			return MessageDecoderResult.OK;
		}

		return MessageDecoderResult.NOT_OK;
	}

	@Override
	public MessageDecoderResult decode(IoSession session, IoBuffer in, ProtocolDecoderOutput out) throws Exception {

		byte[] headerBytes = new byte[CmppMessage.LEN_SSHEADER];
		in.get(headerBytes);

		int messageLength = NetBits.getInt(headerBytes, 0);
		int messageCommand = NetBits.getInt(headerBytes, 4);

		logger.debug("messageCommand" + messageCommand);
		byte[] bodyBytes = null;

		// get body
		if (messageLength > CmppMessage.LEN_SSHEADER) {
			bodyBytes = new byte[messageLength - CmppMessage.LEN_SSHEADER];
			in.get(bodyBytes);
		}

		CmppMessage m;
		if (messageCommand == CmppMessage.CID_CMPP_CONNECT) {
			m = new ConnectRequest();
		} else if (messageCommand == CmppMessage.CID_CMPP_CONNECT_RESP) {
			m = new ConnectResponse();
		} else if (messageCommand == CmppMessage.CID_CMPP_ACTIVETEST) {
			m = new ActiverTestRequest();
		} else if (messageCommand == CmppMessage.CID_CMPP_ACTIVETEST_RESP) {
			m = new ActiverTestResponse();
		} else if (messageCommand == CmppMessage.CID_CMPP_TERMINATE) {
			m = new TerminateRequest();
		} else if (messageCommand == CmppMessage.CID_CMPP_TERMINATE_RESP) {
			m = new TerminateResponse();
		} else if (messageCommand == CmppMessage.CID_CMPP_SUBMIT) {
			m = new SubmitRequest();
		} else if (messageCommand == CmppMessage.CID_CMPP_SUBMIT_RESP) {
			m = new SubmitResponse();
		} else if (messageCommand == CmppMessage.CID_CMPP_DELIVER) {
			m = new DeliverRequest();
		} else if (messageCommand == CmppMessage.CID_CMPP_DELIVER_RESP) {
			m = new DeliverResponse();
		} else {
			logger.error("COMMAND_ID:" + messageCommand + "不是有效的命令！");

			return MessageDecoderResult.NOT_OK;
		}

		m.decodeHeader(headerBytes);
		m.decodeBody(bodyBytes);

		out.write(m);

		return MessageDecoderResult.OK;
	}

	@Override
	public void finishDecode(IoSession session, ProtocolDecoderOutput out) throws Exception {
	}
}