package com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.ConnectResponse;
import com.yijiupi.himalaya.basic.messagesender.util.ConnectionStatus;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * 连接应答消息处理器.
 * 
 * @author: mxyong
 */
@Component(CmppMessage.CMPP_CONNECT_RESP)
public class ConnectResponseHandler implements CMPPMessageHandler {
	private static final Logger logger = LoggerFactory.getLogger(ConnectResponseHandler.class);

	@Override
	public void handle(IoSession session, CmppMessage message) {
		logger.debug("收到登录应答消息.");
		ConnectResponse connectResponse = (ConnectResponse) message;
		if (connectResponse.getStatus() != 0) {
			logger.error("与短信网关[" + session.getRemoteAddress() + "  " + session.getId() + "]的认证失败，短信网关返回的状态码为："
					+ connectResponse.getStatus() + "  " + connectResponse.getVersion() + "  "
					+ connectResponse.getAuthenticatorISMG());
			session.close(true);
			return;
		}
		session.setAttribute(ConnectionStatus.STATUS, ConnectionStatus.STATUS_CONNECTED_LOGIN_SUCESS);
		logger.info("与短信网关[" + session.getRemoteAddress() + "  " + session.getId() + "]的认证成功,登录短信网关成功！");
	}
}
