package com.yijiupi.himalaya.basic.messagesender.config;


public class SingleClientConfig {
    /**
     * 与短信网关的连接数
     */
    private int connectNum;
    /**
     * 每秒发送的流量
     */
    private int flow;

    /**
     * 短信网关端口号
     */
    private int port;

    /**
     * 短信网关IP地址
     */
    private String server;

    /**
     * 连接密码
     */
    private String sharedSecret;

    /**
     * 企业代码
     */
    private String sourceAddr;
    /**
     * 源号码.
     */
    private String srcId;

    public SingleClientConfig(ClientConfig clientConfig) {
        server = clientConfig.server();
        port = clientConfig.port();
        connectNum = clientConfig.connectNum();
        sourceAddr = clientConfig.sourceAddr();
        srcId = clientConfig.srcId();
        sharedSecret = clientConfig.sharedSecret();
    }

    public int getConnectNum() {
        return connectNum;
    }

    public int getFlow() {
        return flow;
    }

    public int getPort() {
        return port;
    }

    public String getServer() {
        return server;
    }

    public String getSharedSecret() {
        return sharedSecret;
    }

    public String getSourceAddr() {
        return sourceAddr;
    }

    public String getSrcId() {
        return srcId;
    }
}
