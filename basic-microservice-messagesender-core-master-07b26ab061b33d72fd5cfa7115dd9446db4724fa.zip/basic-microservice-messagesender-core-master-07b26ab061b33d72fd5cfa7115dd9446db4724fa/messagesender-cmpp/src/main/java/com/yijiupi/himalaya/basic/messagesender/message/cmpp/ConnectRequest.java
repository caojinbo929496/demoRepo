package com.yijiupi.himalaya.basic.messagesender.message.cmpp;

import com.yijiupi.himalaya.basic.messagesender.util.ByteUtility;
import com.yijiupi.himalaya.basic.messagesender.util.DateFormater;
import com.yijiupi.himalaya.basic.messagesender.util.NetBits;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;


/**
 * 
 * 连接网关请求消息
 */
public class ConnectRequest extends CmppMessage {
	public static final void bytesCopy(byte abyte0[], byte abyte1[], int i, int j, int k) {
		int l = 0;
		for (int i1 = i; i1 <= j; i1++) {
			abyte1[k + l] = abyte0[i1];
			l++;
		}
	}

	// 取得登录认证码
	public static final byte[] getAuthString(String time, String sourceAddr, String password)
			throws NoSuchAlgorithmException {
		byte[] user = sourceAddr.getBytes();
		byte[] auth = password.getBytes();
		byte[] timeStamp = time.getBytes();
		if (user == null || auth == null)
			return null;
		byte abyte2[] = new byte[100];
		System.arraycopy(user, 0, abyte2, 0, user.length);// icp
		int k = user.length + 9;
		System.arraycopy(auth, 0, abyte2, k, auth.length);// keys
		k += auth.length;
		System.arraycopy(timeStamp, 0, abyte2, k, 10);// keys
		k += 10;
		byte auths[] = new byte[k];
		System.arraycopy(abyte2, 0, auths, 0, k);// keys

		MessageDigest md = MessageDigest.getInstance("MD5");
		return md.digest(auths);
	}

	private byte authenticatorSP[] = null;// 鉴别源地址
	private String sourceAddr = null;// 源地址

	private int timeStamp;// 时间戳

	private int version;// 版本号

	public ConnectRequest() {
	}

	public ConnectRequest(String sourceAddr, String sharedSecret, int version) throws NoSuchAlgorithmException {
		super(CID_CMPP_CONNECT, createSeqNum());
		this.version = version;
		this.sourceAddr = sourceAddr;
		String timeStr = DateFormater.dateToStr(new Date(), "MMddHHmmss");
		this.timeStamp = Integer.parseInt(timeStr);
		this.authenticatorSP = getAuthString(timeStr, sourceAddr, sharedSecret);
	}

	@Override
	public void decodeBody(byte[] body) throws Exception {
		if (body.length != MESSAGE_CONNECT_BODY_LEN) {
			throw new Exception(CmppMessage.E_INVALID_MSG_HEAD);
		}

		int index = 0;
		sourceAddr = NetBits.getString(body, index, 6);
		index += 6;
		authenticatorSP = NetBits.getBytes(body, index, 16);
		index += 16;
		version = ByteUtility.getIntFromBytes(body, index, 1);
		index += 1;
		timeStamp = ByteUtility.getIntFromBytes(body, index, 4);
	}

	@Override
	public byte[] encodeBody() {
		int index = 0;
		byte[] msg = new byte[MESSAGE_CONNECT_BODY_LEN];

		index = 0;
		NetBits.putString(msg, index, sourceAddr, 6);
		index += 6;
		NetBits.putBytes(msg, index, authenticatorSP, 16);
		index += 16;
		ByteUtility.putIntToBytes(msg, index, version, 1);
		index += 1;
		ByteUtility.putIntToBytes(msg, index, timeStamp, 4);

		return msg;
	}

	public byte[] getAuthenticatorSP() {
		return authenticatorSP;
	}

	@Override
	public String getName() {
		return CMPP_CONNECT;
	}

	public String getSourceAddr() {
		return sourceAddr;
	}

	public int getTimeStamp() {
		return timeStamp;
	}

	public int getVersion() {
		return version;
	}

	public void setAuthenticatorSP(byte[] authenticatorSP) {
		this.authenticatorSP = authenticatorSP;
	}

	public void setSourceAddr(String sourceAddr) {
		this.sourceAddr = sourceAddr;
	}

	public void setTimeStamp(int timeStamp) {
		this.timeStamp = timeStamp;
	}

	public void setVersion(int version) {
		this.version = version;
	}

}
