package com.yijiupi.himalaya.basic.messagesender.util;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * 
 * 时间相关的常用方法
 */
public class DateFormater
{
    public static SimpleDateFormat msformater = new SimpleDateFormat(
        "yyyy-MM-dd HH:mm:ss.SSS");
    public static SimpleDateFormat formater = new SimpleDateFormat(
        "yyyy-MM-dd HH:mm:ss");

    public static SimpleDateFormat formaterA = new SimpleDateFormat(
        "yyMMddHHmm");

    public static SimpleDateFormat dateformater = new SimpleDateFormat(
        "yyyy-MM-dd");
    public static SimpleDateFormat nformater = new SimpleDateFormat(
        "yyyy/MM/dd HH:mm:ss");
    public static SimpleDateFormat timeformater = new SimpleDateFormat(
        "HH:mm:ss");

    public static final int YYMMDDhhmmssxxx = 15;
    public static final int YYYYMMDDhhmmss = 14;
    public static final int YYMMDDhhmmss = 12;
    public static final int YYMMDDhhmm = 10;
    public static final int YYMMDDhh = 8;

    /**
     * 取得本地系统的时间，时间格式由参数决定
     * @param format 时间格式由常量决定
     * @return String 具有format格式的字符串
     */
    public static String getTime(int format)
    {
        StringBuffer timeStr = new StringBuffer(10);
        Calendar time = Calendar.getInstance();
        int miltime = time.get(Calendar.MILLISECOND);
        int second = time.get(Calendar.SECOND);
        int minute = time.get(Calendar.MINUTE);
        int hour = time.get(Calendar.HOUR_OF_DAY);
        int day = time.get(Calendar.DAY_OF_MONTH);
        int month = time.get(Calendar.MONTH) + 1;
        int year = time.get(Calendar.YEAR);

        if (format != 14)
        {
            if (year >= 2000)
                year = year - 2000;
            else
                year = year - 1900;
        }

        if (format >= 2)
        {
            if (format == 14)
                timeStr.append(year);
            else
                timeStr.append(getFormatTime(year, 2));
        }

        if (format >= 4)
            timeStr.append(getFormatTime(month, 2));
        if (format >= 6)
            timeStr.append(getFormatTime(day, 2));
        if (format >= 8)
            timeStr.append(getFormatTime(hour, 2));
        if (format >= 10)
            timeStr.append(getFormatTime(minute, 2));
        if (format >= 12)
            timeStr.append(getFormatTime(second, 2));
        if (format >= 15)
            timeStr.append(getFormatTime(miltime, 3));
        return timeStr.toString();
    }

    /**
     * 产生任意位的字符串
     * @param time 要转换格式的时间
     * @param format 转换的格式
     * @return String 转换的时间
     */
    private static String getFormatTime(int time, int format)
    {
        StringBuffer numm = new StringBuffer();
        int length = String.valueOf(time).length();

        if (format < length)
            return null;

        for (int i = 0; i < format - length; i++)
        {
            numm.append("0");
        }

        numm.append(time);
        return numm.toString().trim();
    }

    public static String dateToString(Date date)
    {
        try
        {
            return formater.format(date);
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    /**
     * 状态报告格式化日期
     * @param date
     * @return
     */
    public static String dateToStringN(String date)
    {
        try
        {
            return nformater.format(date);
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    public static String dateToMSString(Date date)
    {
        try
        {
            return msformater.format(date);
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    public static String calendarToString(Calendar c)
    {
        return dateToString(c.getTime());
    }

    public static String dateToStr(Date date)
    {
        return dateformater.format(date);
    }

    public static String dateToStr(Date date, String format)
    {
        SimpleDateFormat simpledateformat = new SimpleDateFormat(format);
        return simpledateformat.format(date);
    }

    public static String timeToStr(Date date)
    {
        return timeformater.format(date);
    }

    public static String getDateStr(String s)
    {
        int i = s.indexOf(" ");
        if (i > 0)
            return s.substring(0, i);
        else
            return null;
    }

    public static String getTimeStr(String s)
    {
        int i = s.indexOf(" ");
        if (i > 0)
            return s.substring(i + 1);
        else
            return null;
    }

    public static Date strToDateTime(String str)
    {
        synchronized (str)
        {
            try
            {
                return formater.parse(str);
            }
            catch (Exception e)
            {
                return null;
            }
        }
    }

    public static Date stringToDateTime(String str)
    {
        try
        {
            return formater.parse(str);
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public static String stringToDateTimeA(String str)
    {
        try
        {
            return formater.format(str);
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public static Date strToDate(String s)
    {
        try
        {
            return dateformater.parse(s);
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public static Date strToTime(String s)
    {
        try
        {
            return timeformater.parse(s);
        }
        catch (Exception e)
        {
            return null;
        }
    }

    public static String toDateStr(Calendar c)
    {
        return toDateStr(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c
            .get(Calendar.DAY_OF_MONTH));
    }

    public static String toDateStr(int year, int month, int day)
    {
        StringBuffer sb = new StringBuffer();

        sb.append(year);
        sb.append("/");

        if (month < 10)
            sb.append("0");
        sb.append(month);
        sb.append("/");

        if (day < 10)
            sb.append("0");
        sb.append(day);

        return sb.toString();
    }

    public static String toTimeStr(Calendar c)
    {
        return toTimeStr(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), c
            .get(Calendar.SECOND));
    }

    public static String toTimeStr(int hour, int minute, int second)
    {
        StringBuffer sb = new StringBuffer();

        if (hour < 10)
            sb.append("0");
        sb.append(hour);
        sb.append(":");

        if (minute < 10)
            sb.append("0");
        sb.append(minute);
        sb.append(":");

        if (second < 10)
            sb.append("0");
        sb.append(second);

        return sb.toString();
    }

    public static Date toTimeStrA(String s)
    {
        Date a = null;
        try
        {
            a = formaterA.parse(s);
        }
        catch (ParseException e)
        {
            a = null;
        }
        return a;
    }
    
    private static final String cmppformat = "{0,number,00}{1,number,00}{2,number,00}{3,number,00}{4,number,00}"
        + "{5,number,00}{6,number,0}{7,number,00}{8}";

    public static String getCmppDateStr(String dStr)
    {
        int year = 0;
        int month = 0;
        int day = 0;
        int hour = 0;
        int minute = 0;
        int second = 0;
        int tenth = 0;
        int utcOffset = 0;
        char sign = '+';
        TimeZone savedTimeZone = null;
        
        Date d  = DateFormater.stringToDateTime(dStr);
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
   
        year = cal.get(Calendar.YEAR) - 2000;
        month = cal.get(Calendar.MONTH) + 1;
        day = cal.get(Calendar.DAY_OF_MONTH);
        hour = cal.get(Calendar.HOUR_OF_DAY);
        minute = cal.get(Calendar.MINUTE);
        second = cal.get(Calendar.SECOND);
        tenth = cal.get(Calendar.MILLISECOND) / 100;
        savedTimeZone = cal.getTimeZone();
        // Time zone calculation
        sign = '+';
        long off = savedTimeZone.getRawOffset();
        if (off < 0)
            sign = '-';
        // Calculate the difference in quarter hours.
        utcOffset = ((int) Math.abs(off) / 900000);
        Object[] args = { new Integer(year), new Integer(month),
            new Integer(day), new Integer(hour), new Integer(minute),
            new Integer(second), new Integer(tenth), new Integer(utcOffset),
            new Character(sign) };

        return (MessageFormat.format(cmppformat, args));
    }
}