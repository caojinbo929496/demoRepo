package com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import com.yijiupi.himalaya.basic.messagesender.util.ConnectionStatus;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * 链路检测包应答消息处理.
 * 
 * @author: mxyong
 */
@Component(CmppMessage.CMPP_ACTIVETEST_RESP)
public class ActiveTestResponseHandler implements CMPPMessageHandler {
	private static final Logger logger = LoggerFactory.getLogger(ActiveTestResponseHandler.class);

	@Override
	public void handle(IoSession session, CmppMessage message) {
		logger.debug("收到链路检测包应答.");
		session.removeAttribute(ConnectionStatus.ACTIVERTESTCOUNT);
	}

}
