package com.yijiupi.himalaya.basic.messagesender.message.cmpp;


import com.yijiupi.himalaya.basic.messagesender.util.ByteUtility;

/**
 * 
 * 链路检测应答消息
 */
public class ActiverTestResponse extends CmppMessage {
	private int result = 0;

	public ActiverTestResponse() {

	}

	public ActiverTestResponse(int messageSequence) {
		super(CmppMessage.CID_CMPP_ACTIVETEST_RESP, messageSequence);
	}

	@Override
	public void decodeBody(byte[] body) throws Exception {

		if (body.length != MESSAGE_ACTIVE_RESP_BODY_LEN)
			throw new Exception(CmppMessage.E_INVALID_MSG_HEAD);

		int index = 0;

		result = ByteUtility.getIntFromBytes(body, index, 1);
	}

	@Override
	public byte[] encodeBody() {
		int index = 0;
		byte[] msg = new byte[MESSAGE_ACTIVE_RESP_BODY_LEN];

		index = 0;
		ByteUtility.putIntToBytes(msg, index, result, 1);

		return msg;
	}

	@Override
	public String getName() {
		return CMPP_ACTIVETEST_RESP;
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

}