package com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.TerminateRequest;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.TerminateResponse;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * 拆除链接请求处理.
 * 
 * @author: mxyong
 */
@Component(CmppMessage.CMPP_TERMINATE)
public class TerminateRequestHandler implements CMPPMessageHandler {
	private static final Logger logger = LoggerFactory.getLogger(TerminateRequestHandler.class);

	@Override
	public void handle(IoSession session, CmppMessage message) {
		logger.debug("收到断开连接请求.");
		TerminateRequest tr = (TerminateRequest) message;
		TerminateResponse trp = new TerminateResponse(tr.getMessageSequence());
		session.write(trp);
		session.close(true);
	}

}
