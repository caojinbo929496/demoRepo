package com.yijiupi.himalaya.basic.messagesender.message.cmpp;

import java.io.Serializable;

/**
 * 消息体接口
 * 
 * @author Administrator
 *
 */
public interface CmppBody extends Serializable {
	/**
	 * 解码.
	 * 
	 * @param bodyBytes
	 * @throws Exception
	 * @return: void
	 */
	public void decodeBody(byte[] bodyBytes) throws Exception;

	/**
	 * 编码.
	 * 
	 * @return
	 * @return: byte[]
	 */
	public byte[] encodeBody();
}
