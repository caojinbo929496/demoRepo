
package com.yijiupi.himalaya.basic.messagesender.util;

/**
 * 创建一个OFFSET,用于Bits偏移
 */
public class OffSet
{
	private int off;
    
    public OffSet(int off)
    {
    	this.off = off;
    }
    
    public void setOff(int off)
    {
    	this.off = off;
    }
    
    public int getOff()
    {
    	return off;
    }
}
