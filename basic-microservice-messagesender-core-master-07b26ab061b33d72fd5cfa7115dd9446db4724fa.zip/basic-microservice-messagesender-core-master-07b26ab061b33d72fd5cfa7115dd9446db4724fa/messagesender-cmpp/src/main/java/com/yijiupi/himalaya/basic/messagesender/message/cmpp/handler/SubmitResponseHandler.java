package com.yijiupi.himalaya.basic.messagesender.message.cmpp.handler;

import com.yijiupi.himalaya.basic.messagesender.message.cmpp.CmppMessage;
import com.yijiupi.himalaya.basic.messagesender.message.cmpp.SubmitResponse;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * submit应答消息处理.
 * 
 * @author: mxyong
 */
@Component(CmppMessage.CMPP_SUBMIT_RESP)
public class SubmitResponseHandler implements CMPPMessageHandler {
	private static final Logger logger = LoggerFactory.getLogger(SubmitResponseHandler.class);

	@Override
	public void handle(IoSession session, CmppMessage message) {
		logger.debug("收到下行应答消息.");
		SubmitResponse submitResponse = (SubmitResponse) message;

		try {
			// 流控错
			if (submitResponse.getStatus() == 8) {
				logger.info("短信网关[" + session.getRemoteAddress() + "  " + session.getId() + "]流量控制，休眠500毫秒！");
				session.suspendWrite();
				Thread.sleep(500);
			}
			// 其他错误
			if (submitResponse.getStatus() != 0) {
				throw new RuntimeException("submit消息应答错误:" + submitResponse.getStatus());
			}

		} catch (InterruptedException e) {
		} finally {
			if (session.isWriteSuspended()) {
				session.resumeWrite();
			}
		}
	}

}
