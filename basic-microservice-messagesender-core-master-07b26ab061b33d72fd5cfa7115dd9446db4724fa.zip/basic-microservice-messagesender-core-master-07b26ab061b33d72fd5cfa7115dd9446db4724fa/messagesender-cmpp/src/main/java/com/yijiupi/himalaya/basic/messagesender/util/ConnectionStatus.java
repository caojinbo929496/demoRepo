package com.yijiupi.himalaya.basic.messagesender.util;

/**
 * 连接状态常量.
 * 
 * @author: mxyong
 * @date: 2016年7月10日 下午4:17:11
 */
public class ConnectionStatus {
	/**
	 * 发送链路检测包未收到应答的次数.
	 */
	public static final String ACTIVERTESTCOUNT = "ACTIVERTESTCOUNT";

	/**
	 * 连接配置.
	 */
	public static final String CONNECT_CONFIG = "CONNECT_CONFIG";

	/**
	 * 流量控制.
	 */
	public static final String FLOW_REGULATION = "FLOW_REGULATION";

	/**
	 * 是否重新连接标识.
	 */
	public static final String RECONECT = "RECONECT";

	/**
	 * 连接状态.
	 */
	public static final String STATUS = "STATUS";

	/**
	 * 登录成功.
	 */
	public static final String STATUS_CONNECTED_LOGIN_SUCESS = "LOGIN_SUCESS";

	/**
	 * 正在进行登录请求
	 */
	public static final String STATUS_CONNECTED_LOGINING = "LOGINING";

	private ConnectionStatus() {

	}

}
