package com.yijiupi.himalaya.basic.messagesender.beans;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class HttpClientUtil {


    public String doPost(List<NameValuePair> data, String url) throws Exception {
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(url);
            // 设置连接超时，请求超时
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(2000)
                    .setConnectionRequestTimeout(2000).setSocketTimeout(2000).build();
            httpPost.setConfig(requestConfig);
            httpPost.setEntity(new UrlEncodedFormEntity(data, "utf-8"));

            // 响应处理器.
            ResponseHandler<String> responseHandler = response -> {
                int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity entity = response.getEntity();
                    return entity != null ? EntityUtils.toString(entity) : null;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
            };
            return httpclient.execute(httpPost, responseHandler);
        }
    }

    public String doGet(String url) throws Exception {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        CloseableHttpResponse response = null;
        try {
            HttpGet httpGet = new HttpGet(url);

            // 设置连接超时，请求超时
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(2000)
                    .setConnectionRequestTimeout(2000).setSocketTimeout(2000).build();
            httpGet.setConfig(requestConfig);

            response = httpclient.execute(httpGet);
            HttpEntity entity = response.getEntity();
            return EntityUtils.toString(entity);
        } finally {
            httpclient.close();
            if(response != null){
                response.close();
            }
        }
    }

    /**
     * 每200个手机号拼成一个字符串，以,分割
     */
    public List<String> toMobileString(List<String> mobileList, int listSize) {
        // 去重
        List<String> mobileListNoDuplicate = mobileList.stream().distinct().collect(Collectors.toList());

        List<String> mobileStringList = new ArrayList<>();

        int size = mobileListNoDuplicate.size();
        int begin = 0;
        int end = listSize;
        while (size/end != 0) {
            mobileListNoDuplicate.subList(begin, end).stream().reduce((sum, item) -> sum + "," + item).ifPresent(mobileStringList::add);
            begin = end;
            end = end + listSize;
        }
        mobileListNoDuplicate.subList(begin, size).stream().reduce((sum, item) -> sum + "," + item).ifPresent(mobileStringList::add);
        return mobileStringList;
    }
}
