package com.yijiupi.himalaya.basic.message.domain.dao;

import java.util.List;
import java.util.Map;

import com.yijiupi.himalaya.basic.message.domain.bo.BlackListResult;
import com.yijiupi.himalaya.basic.message.domain.po.MessageNumListPO;

public interface MessageNumListPOMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MessageNumListPO record);

    int insertSelective(MessageNumListPO record);

    int updateByPrimaryKeySelective(MessageNumListPO record);

    int updateByPrimaryKey(MessageNumListPO record);
    
    
    Integer findCountByMobileAndPagerCondition(Map<String, Object> map);
    
    List<BlackListResult> findByMobileAndPagerCondition(Map<String, Object> map);
    
    List<String> checkMobileListOfBlackList(List<String> mobileList);
    
    int checkMobileOfBlackList(String mobile); 
    
}