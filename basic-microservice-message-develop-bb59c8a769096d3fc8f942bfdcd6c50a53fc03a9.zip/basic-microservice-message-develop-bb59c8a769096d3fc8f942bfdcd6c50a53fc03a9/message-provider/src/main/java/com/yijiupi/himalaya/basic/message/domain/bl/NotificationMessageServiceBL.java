package com.yijiupi.himalaya.basic.message.domain.bl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;


import com.google.gson.Gson;
import com.yijiupi.himalaya.basic.message.service.NotificationMessageService;
import com.yijiupi.himalaya.masterdata.bizuser.service.IBizUserQueryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.dubbo.config.annotation.Reference;
import com.yijiupi.himalaya.base.exception.BusinessValidateException;
import com.yijiupi.himalaya.basic.message.dto.NotificationMessageDTO;
import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageDTO;
import com.yijiupi.himalaya.basic.message.enums.PushType;
import com.yijiupi.himalaya.masterdata.adminuser.domain.enums.EnableState;
import com.yijiupi.himalaya.masterdata.adminuser.domain.org.CityOrg;
import com.yijiupi.himalaya.masterdata.adminuser.domain.org.CityType;
import com.yijiupi.himalaya.masterdata.adminuser.service.ICityService;
import com.yijiupi.himalaya.masterdata.bizuser.service.IBizUserService;
import com.yijiupi.himalaya.trading.setting.domain.setting.enums.NotificationType;
import com.yijiupi.himalaya.trading.setting.domain.settingItems.message.NotificationSetting;
import com.yijiupi.himalaya.trading.setting.service.ISettingService;

@Component
public class NotificationMessageServiceBL {
    @Reference
    private IBizUserService bizUserService;

    @Reference
    private IBizUserQueryService iBizUserQueryService;

    @Reference
    private ICityService cityService;

    @Autowired
    PushMessageBL pushMessageBL;

    @Reference
    private ISettingService settingService;

    @Autowired
    SMSMessageServiceBL smsMessageServiceBL;


    @Autowired
    private Gson gson;

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationMessageServiceBL.class);

    /**
     * 获取所有2.0城市.
     *
     * @return
     * @return: List<CityOrg>
     */
    private List<CityOrg> findAll20City() {
        return cityService.findCitySelectArea(EnableState.启用.value);
    }

    /**
     * 给城市下所有用户发送信息
     *
     * @return: void
     */
    private List<String> findUserByCityId(Integer cityId) {
       return bizUserService.getMobileNoByCityId(cityId);
    }

    /**
     * 获取通知方式.
     *
     * @param notificationMessageDTO
     * @return
     * @return: NotificationType
     */
    private NotificationType getSendType(NotificationMessageDTO notificationMessageDTO) {
        NotificationSetting notificationSetting = settingService.getNotificationSetting(notificationMessageDTO.getMallAppType());
        return notificationSetting.getSettings().get(notificationMessageDTO.getMessageBusinessType().toString());
    }

    public void sendNotificationMessage(NotificationMessageDTO notificationMessageDTO) {
        NotificationType notificationType = getSendType(notificationMessageDTO);
        LOGGER.info("收到通知，参数：{}，通知类型：{}", gson.toJson(notificationMessageDTO), notificationType.name());

        if (notificationType.equals(NotificationType.推送通知)) {
            PushMessageDTO pushMessageDTO = toPushMessageDTO(notificationMessageDTO);
            pushMessageBL.pushAppMessage(pushMessageDTO);
        }

        if (notificationType.equals(NotificationType.短信通知)) {
            SMSMessageDTO smsMessageDTO = toSmsMessageDTO(notificationMessageDTO);
            smsMessageServiceBL.sendMessage(smsMessageDTO);
        }
    }

    /**
     * 转换成对应的推送消息.
     *
     * @param notificationMessageDTO
     * @return
     * @return: PushMessageDTO
     */
    private PushMessageDTO toPushMessageDTO(NotificationMessageDTO notificationMessageDTO) {

        List<String> tagOrIdList = new ArrayList<>();
        PushMessageDTO pushMessageDTO = new PushMessageDTO();
        pushMessageDTO.setMallAppType(notificationMessageDTO.getMallAppType());
        if (PushType.全国推送.equals(notificationMessageDTO.getPushType())) {
            List<CityOrg> cityList = findAll20City();
            for (CityOrg cityOrg : cityList) {
                Integer cityId = cityOrg.getId();
                tagOrIdList.add(String.valueOf(cityId));
            }
            pushMessageDTO.setTagOrIdList(tagOrIdList);
            pushMessageDTO.setPushType(PushType.全国推送);
        } else if (PushType.城市推送.equals(notificationMessageDTO.getPushType())) {
            CityOrg cityOrg = cityService.getCity(notificationMessageDTO.getCityId());
            // 判断城市的版本是1.0还是2.0，因为1.0消息不用处理
            if (cityOrg != null && CityType.v2.equals(cityOrg.getCityType())) {
                tagOrIdList.add(String.valueOf(notificationMessageDTO.getCityId()));
                pushMessageDTO.setTagOrIdList(tagOrIdList);
                pushMessageDTO.setPushType(PushType.城市推送);
            }
        } else if (PushType.用户推送.equals(notificationMessageDTO.getPushType())) {
            if (notificationMessageDTO.getUserIdList() == null || notificationMessageDTO.getUserIdList().isEmpty()) {
                throw new BusinessValidateException("推送消息推给用户，但用户的Id集合为null！");
            }
            tagOrIdList = iBizUserQueryService.listAliasId(new HashSet<>(notificationMessageDTO.getUserIdList()));
            pushMessageDTO.setTagOrIdList(tagOrIdList);
            pushMessageDTO.setPushType(PushType.用户推送);
        }
        pushMessageDTO.setContent(notificationMessageDTO.getContent());
        pushMessageDTO.setPushAPPType(notificationMessageDTO.getPushAPPType());

        return pushMessageDTO;
    }

    /**
     * 转换成对应的短信消息.
     *
     * @param notificationMessageDTO
     * @return
     * @return: SMSMessageDTO
     */
    private SMSMessageDTO toSmsMessageDTO(NotificationMessageDTO notificationMessageDTO) {
        // 构造发送短信的对象
        SMSMessageDTO smsMessageDTO = new SMSMessageDTO();
        smsMessageDTO.setContent(notificationMessageDTO.getContent());
        smsMessageDTO.setMallAppType(notificationMessageDTO.getMallAppType());
        if (PushType.全国推送.equals(notificationMessageDTO.getPushType())) {
            List<CityOrg> cityList = findAll20City();
            for (CityOrg cityOrg : cityList) {
                smsMessageDTO.getMobileList().addAll(findUserByCityId(null));
            }
        } else if (PushType.城市推送.equals(notificationMessageDTO.getPushType())) {
            CityOrg cityOrg = cityService.getCity(notificationMessageDTO.getCityId());
            // 判断城市的版本是1.0还是2.0，因为1.0消息不用处理
            if (cityOrg != null && CityType.v2.equals(cityOrg.getCityType())) {
                smsMessageDTO.getMobileList().addAll(findUserByCityId(cityOrg.getId()));
            }
        } else if (PushType.用户推送.equals(notificationMessageDTO.getPushType())) {
            if (notificationMessageDTO.getMobileList() == null) {
                notificationMessageDTO.setMobileList(notificationMessageDTO.getUserIdList().stream().map(p -> bizUserService.getBizUserDetail(p).getMobileNo()).collect(Collectors.toList()));
            }
            smsMessageDTO.setMobileList(notificationMessageDTO.getMobileList());
        }
        return smsMessageDTO;
    }
}
