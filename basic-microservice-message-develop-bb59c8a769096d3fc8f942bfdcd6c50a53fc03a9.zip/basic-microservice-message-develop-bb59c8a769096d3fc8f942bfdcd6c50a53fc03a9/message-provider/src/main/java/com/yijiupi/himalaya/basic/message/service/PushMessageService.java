package com.yijiupi.himalaya.basic.message.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.yijiupi.himalaya.basic.message.domain.bl.PushMessageBL;
import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;

@Service
public class PushMessageService implements IPushMessageService {

	@Autowired
	private PushMessageBL pushMessageBL;

	@Override
	public void pushAppMessage(PushMessageDTO pushMessage) {
		pushMessageBL.pushAppMessage(pushMessage);
	}

}
