package com.yijiupi.himalaya.basic.message.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.yijiupi.himalaya.basic.message.domain.bl.VoiceMessageServiceBL;
import com.yijiupi.himalaya.basic.message.dto.VoiceMessageDTO;

@Service
public class VoiceMessageService implements IVoiceMessageService {

	@Autowired
	private VoiceMessageServiceBL voiceMessageServiceBL;

	@Override
	public void sendMessage(VoiceMessageDTO voiceMessage) {
		String mobile = voiceMessage.getMobile();
		String content = voiceMessage.getContent();
		voiceMessageServiceBL.validate(mobile, content);
		voiceMessageServiceBL.sendMessage(voiceMessage);
	}

}
