package com.yijiupi.himalaya.basic.message.domain.bl;

import com.yijiupi.himalaya.base.exception.BusinessValidateException;
import com.yijiupi.himalaya.basic.message.domain.dao.MessageNumListPOMapper;
import com.yijiupi.himalaya.basic.message.dto.VoiceMessageDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class VoiceMessageServiceBL {
	
	@Value("${spring.rabbitmq.sendVoiceMessageQueue}")
	private String yjp_Message_Voice;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SMSMessageServiceBL.class);
	
	@Autowired
	private MessageNumListPOMapper messageNumListPOMapper;
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	public void sendMessage(VoiceMessageDTO voiceMessage) {
		String mobile = voiceMessage.getMobile();
		String content = voiceMessage.getContent();
		if(messageNumListPOMapper.checkMobileOfBlackList(mobile) > 0){
			throw new BusinessValidateException("发送失败：该用户在黑名单中");
		}
		rabbitTemplate.convertAndSend(yjp_Message_Voice, "", voiceMessage);
		LOGGER.info("发送语音日志记录：手机号码：{}，语音内容：{}", mobile, content);
	}
	
	public void validate(String mobile, String content)  {
		if (mobile == null) {
			throw new BusinessValidateException("手机号码不能为空！");
		}
		if (content == null || "".equals(content)) {
			throw new BusinessValidateException("语音内容不能为空！");
		}
		String regex_mobile = "^\\d{11}$";
		if(!mobile.matches(regex_mobile)){
			throw new BusinessValidateException("手机号码不合法！");
		}
		String regex_content = "^\\d{4,8}$";
		if(!content.matches(regex_content)){
			throw new BusinessValidateException("语音内容不合法！");
		}
	}
	
}
