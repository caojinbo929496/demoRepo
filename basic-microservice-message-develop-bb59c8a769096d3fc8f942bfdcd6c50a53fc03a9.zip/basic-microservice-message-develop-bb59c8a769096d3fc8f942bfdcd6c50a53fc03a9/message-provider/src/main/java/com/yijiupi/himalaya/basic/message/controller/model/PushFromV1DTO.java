package com.yijiupi.himalaya.basic.message.controller.model;

import com.yijiupi.himalaya.base.enums.MallAppType;
import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;
import com.yijiupi.himalaya.basic.message.enums.PushAPPType;
import com.yijiupi.himalaya.basic.message.enums.PushType;

import java.util.Collections;
import java.util.List;

/**
 * 推送dto对象
 */
public class PushFromV1DTO {
    /**
     * 推送内容
     */
    private String content;

    /**
     * 推送用户1.0id
     */
    private String userIdv1;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUserIdv1() {
        return userIdv1;
    }

    public void setUserIdv1(String userIdv1) {
        this.userIdv1 = userIdv1;
    }

    public PushMessageDTO buildPushMessageDTO() {
        PushMessageDTO pushMessageDTO = new PushMessageDTO();
        pushMessageDTO.setMallAppType(MallAppType.酒批);
        pushMessageDTO.setContent(content);
        pushMessageDTO.setPushType(PushType.用户推送);
        pushMessageDTO.setTagOrIdList(Collections.singletonList(userIdv1));
        pushMessageDTO.setPushAPPType(PushAPPType.E_JIU_PI);
        return pushMessageDTO;
    }
}
