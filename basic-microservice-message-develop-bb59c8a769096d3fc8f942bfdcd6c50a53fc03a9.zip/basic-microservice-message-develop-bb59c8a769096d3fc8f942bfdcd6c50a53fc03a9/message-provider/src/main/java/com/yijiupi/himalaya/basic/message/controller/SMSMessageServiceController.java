package com.yijiupi.himalaya.basic.message.controller;

import java.util.List;

import org.junit.validator.PublicClassValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yijiupi.himalaya.basic.message.dto.SMSMessageDTO;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageHistory;
import com.yijiupi.himalaya.basic.message.dto.SMSSingleMessageDTO;
import com.yijiupi.himalaya.basic.message.service.ISMSMessageService;

/**
 * 短信服务控制器
 * 
 * @author lidehu
 * @date 2016年12月7日15:20:59
 *
 */
@RestController
public class SMSMessageServiceController {

	private static final Logger LOGGER = LoggerFactory.getLogger(SMSMessageServiceController.class);
	
	@Autowired
	private ISMSMessageService ismsMessageService;
	
	/**
	 * 批量发送短信
	 */
	@RequestMapping(value = "/sms/sendMessage", method = RequestMethod.POST)
    public BaseResult sendMessage(@RequestBody SMSMessageDTO smsMessageDTO) {
		try {
			ismsMessageService.sendMessageFromV1(smsMessageDTO);
		} catch (Exception e) {
			LOGGER.error("jiupiV1调用短信接口，手机号码：{}，短信内容：{}", smsMessageDTO.getMobileList(), smsMessageDTO.getContent());
			return BaseResult.getFailedResult(e);
		}
		return BaseResult.getSuccessResult();
    }
	
	/**
	 * 单个发送短信
	 */
	@RequestMapping(value = "/sms/sendSingleMessage", method = RequestMethod.POST)
    public BaseResult sendSingleMessage(@RequestBody SMSSingleMessageDTO smsSingleMessage) {
		try {
			ismsMessageService.sendSingleMessage(smsSingleMessage);
		} catch (Exception e) {
			LOGGER.error("jiupiV1调用短信接口，手机号码：{}，短信内容：{}", smsSingleMessage.getMobile(), smsSingleMessage.getContent());
			return BaseResult.getFailedResult(e);
		}
		return BaseResult.getSuccessResult();
    }
	
}
