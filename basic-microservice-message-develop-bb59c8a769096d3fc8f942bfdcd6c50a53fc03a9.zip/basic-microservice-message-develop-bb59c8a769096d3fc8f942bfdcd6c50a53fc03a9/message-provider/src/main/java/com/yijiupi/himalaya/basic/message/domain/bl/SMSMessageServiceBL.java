package com.yijiupi.himalaya.basic.message.domain.bl;

import com.yijiupi.himalaya.base.exception.BusinessValidateException;
import com.yijiupi.himalaya.base.search.PageList;
import com.yijiupi.himalaya.base.search.Pager;
import com.yijiupi.himalaya.base.search.PagerCondition;
import com.yijiupi.himalaya.basic.message.domain.bo.BlackListResult;
import com.yijiupi.himalaya.basic.message.domain.converter.BlackListResultConverter;
import com.yijiupi.himalaya.basic.message.domain.converter.MessagePOConverter;
import com.yijiupi.himalaya.basic.message.domain.dao.MessageNumListPOMapper;
import com.yijiupi.himalaya.basic.message.domain.dao.MessagePOMapper;
import com.yijiupi.himalaya.basic.message.domain.po.MessageNumListPO;
import com.yijiupi.himalaya.basic.message.domain.po.MessagePO;
import com.yijiupi.himalaya.basic.message.dto.Blacklist;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageDTO;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageHistory;
import com.yijiupi.himalaya.basic.message.dto.SMSSingleMessageDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class SMSMessageServiceBL {
	
	@Value("${spring.rabbitmq.sendSMSMessageQueue}")
	private String yjp_Message_SMS;

    @Value("${spring.rabbitmq.sendSMSMessageQueueV1}")
	private String yjp_Message_SMS_V1;

	@Value("${spring.rabbitmq.sendSMSSingleMessageQueue}")
	private String yjp_Message_SMS_Single;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SMSMessageServiceBL.class);
	
	@Autowired
	private MessageNumListPOMapper messageNumListPOMapper;
	@Autowired
	private MessagePOMapper messagePOMapper;
	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	
	public void addBlacklist(String mobile) {
		MessageNumListPO record = new MessageNumListPO();
		record.setCreatetime(new Date());
		record.setListtype((byte)(0));
		record.setMobileno(mobile);
		messageNumListPOMapper.insertSelective(record);
	}

	public PageList<Blacklist> findBlacklist(String mobile, PagerCondition pagerCondition) {
		PageList<Blacklist> pageList = new PageList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("mobile", mobile);
		map.put("offSet", pagerCondition.getOffset());
		map.put("pageSize", pagerCondition.getPageSize());
		List<BlackListResult> list = messageNumListPOMapper.findByMobileAndPagerCondition(map);
		List<Blacklist> dataList = new ArrayList<>();
		for(BlackListResult result : list){
			Blacklist blackList = BlackListResultConverter.blackListResultToDTO(result);
			dataList.add(blackList);
		}
		pageList.setDataList(dataList);
		Integer count = messageNumListPOMapper.findCountByMobileAndPagerCondition(map);
		Pager pager = new Pager(pagerCondition,count);
		pageList.setPager(pager);
		return pageList;
	}

	public List<SMSMessageHistory> findSMSMessageListByMobile(String mobile) {
		List<SMSMessageHistory> smsmessageHistoryList = new ArrayList<>();
		List<MessagePO> messagePOList = messagePOMapper.findByMobile(mobile);
		for(MessagePO messagePO : messagePOList){
			SMSMessageHistory smsMessageHistory = MessagePOConverter.messagePOToDTO(messagePO);
			smsmessageHistoryList.add(smsMessageHistory);
		}
		return smsmessageHistoryList;
	}

	public void removeBlacklist(Integer id) {
		messageNumListPOMapper.deleteByPrimaryKey(id);
	}
	
	public void sendMessage(SMSMessageDTO smsMessageDTO) {
        sendBatchMessage(smsMessageDTO);
		rabbitTemplate.convertAndSend(yjp_Message_SMS, "", smsMessageDTO);
		LOGGER.info("发送短信日志记录：手机号码：{}，短信内容：{}", smsMessageDTO.getMobileList(), smsMessageDTO.getContent());
	} 
	
	public boolean sendMessage(SMSSingleMessageDTO smsSingleMessage) {
		String mobile = smsSingleMessage.getMobile();
		String content = smsSingleMessage.getContent();
		if(messageNumListPOMapper.checkMobileOfBlackList(mobile) > 0){
			return false;
		}
		//调用saveMessageHistory将发送的短信保存到历史纪录中
		saveMessageHistory(mobile, content);
		rabbitTemplate.convertAndSend(yjp_Message_SMS_Single,"", smsSingleMessage);
		LOGGER.info("发送短信日志记录：手机号码：{}，短信内容：{}", mobile, content);
		return true;
	}
	
	
	/**
	 * 发送的短信保存到历史纪录中
	 * 
	 * @param content
	 */
	private void saveMessageHistory(String mobile, String content){
		MessagePO messagePO = new MessagePO();
		messagePO.setIssuccess(true);
		messagePO.setMobileno(mobile);
		messagePO.setContent(content);
		messagePO.setCreatetime(new Date());
		messagePOMapper.insertSelective(messagePO);
	}
	
	/**
	 * 批量手机数据验证
	 */
	public void validate(List<String> mobileList, String content)  {
		if (CollectionUtils.isEmpty(mobileList)) {
			throw new BusinessValidateException("手机号码不能为空！");
		}
		if (content == null || "".equals(content)) {
			throw new BusinessValidateException("短信内容不能为空！");
		}
		String regex = "^\\d{11}$";
		mobileList = mobileList.stream().filter(p->p.matches(regex)).collect(Collectors.toList());
		if(mobileList.isEmpty()) {
			throw new BusinessValidateException("手机号码不合法！");
		}
	}
	
	/**
	 * 单个手机数据验证
	 */
	public void validate(String mobile, String content)  {
		if (StringUtils.isEmpty(mobile)) {
			throw new BusinessValidateException("手机号码不能为空！");
		}
		if (content == null || "".equals(content)) {
			throw new BusinessValidateException("短信内容不能为空！");
		}
		String regex = "^\\d{11}$";
		if(!mobile.matches(regex)){
			throw new BusinessValidateException("手机号码:"+mobile+"不合法！");
		}
	}

	public void sendMessageFromV1(SMSMessageDTO smsMessageDTO) {
        sendBatchMessage(smsMessageDTO);
		rabbitTemplate.convertAndSend(yjp_Message_SMS_V1, "", smsMessageDTO);
        LOGGER.info("发送短信日志记录：手机号码：{}，短信内容：{}", smsMessageDTO.getMobileList(), smsMessageDTO.getContent());
	}

	private void sendBatchMessage(SMSMessageDTO smsMessageDTO) {
        String content = smsMessageDTO.getContent();
        List<String> mobileList = smsMessageDTO.getMobileList();
        List<String> mobileInBlack = messageNumListPOMapper.checkMobileListOfBlackList(mobileList);
        mobileList.removeAll(mobileInBlack);
        if(mobileList.isEmpty()){
            return;
        }
        smsMessageDTO.setMobileList(mobileList);
        for(String mobile : mobileList){
            //调用saveMessageHistory将发送的短信保存到历史纪录中
            saveMessageHistory(mobile, smsMessageDTO.getMallAppType().name() + content);
        }
    }
}
