package com.yijiupi.himalaya.basic.message.domain.converter;

import com.yijiupi.himalaya.basic.message.domain.po.MessagePO;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageHistory;

public class MessagePOConverter {

	public static SMSMessageHistory messagePOToDTO(MessagePO messagePO) {
		SMSMessageHistory messageHistory = new SMSMessageHistory();
		messageHistory.setContent(messagePO.getContent());
		messageHistory.setCreateTime(messagePO.getCreatetime());
		messageHistory.setErrorMessage(messagePO.getErrormessage());
		messageHistory.setExtras(messagePO.getExtras());
		messageHistory.setIsSucess(messagePO.getIssuccess());
		messageHistory.setmobile(messagePO.getMobileno());
		return messageHistory;
	}

}
