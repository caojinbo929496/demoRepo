package com.yijiupi.himalaya.basic.message.service;

import com.google.gson.Gson;
import com.yijiupi.himalaya.base.exception.BusinessValidateException;
import com.yijiupi.himalaya.basic.message.domain.bl.NotificationMessageServiceBL;
import com.yijiupi.himalaya.basic.message.dto.NotificationMessageDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;

import org.springframework.util.CollectionUtils;

/**
 * 由系统设置的消息推送.
 * 
 * @author: mxyong
 * @date: 2016年8月30日 下午9:43:17
 */
@Service(timeout = 12000)
public class NotificationMessageService implements INotificationMessageService {
	@Autowired
	NotificationMessageServiceBL notificationMessageServiceBL;


	@Override
	public void sendNotificationMessage(NotificationMessageDTO notificationMessageDTO) {
		if (CollectionUtils.isEmpty(notificationMessageDTO.getUserIdList())) {
			throw new BusinessValidateException("用户ID不能为空");
		}
		notificationMessageServiceBL.sendNotificationMessage(notificationMessageDTO);
	}

}
