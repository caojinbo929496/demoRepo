package com.yijiupi.himalaya.basic.message.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.yijiupi.himalaya.base.exception.BusinessValidateException;
import com.yijiupi.himalaya.base.search.PageList;
import com.yijiupi.himalaya.base.search.PagerCondition;
import com.yijiupi.himalaya.base.utils.ValidateHelper;
import com.yijiupi.himalaya.basic.message.domain.bl.SMSMessageServiceBL;
import com.yijiupi.himalaya.basic.message.dto.Blacklist;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageDTO;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageHistory;
import com.yijiupi.himalaya.basic.message.dto.SMSSingleMessageDTO;

@Service
public class SMSMessageService implements ISMSMessageService {

	@Autowired
	private SMSMessageServiceBL smsMessageServiceBL;

	@Override
	public void addBlacklist(String mobile) {
		if (!ValidateHelper.isMobileNo(mobile)) {
			throw new BusinessValidateException("手机号格式不正确");
		}
		smsMessageServiceBL.addBlacklist(mobile);
	}

	@Override
	public PageList<Blacklist> findBlacklist(String mobile, PagerCondition pagerCondition) {
		return smsMessageServiceBL.findBlacklist(mobile, pagerCondition);
	}

	@Override
	public List<SMSMessageHistory> findSMSMessageListByMobile(String mobile) {
		return smsMessageServiceBL.findSMSMessageListByMobile(mobile);
	}

	@Override
	public void removeBlacklist(Integer id) {
		smsMessageServiceBL.removeBlacklist(id);
	}

	@Override
	public void sendMessage(SMSMessageDTO smsMessageDTO) {
		List<String> mobileList = smsMessageDTO.getMobileList();
		String content = smsMessageDTO.getContent();
		smsMessageServiceBL.validate(mobileList, content);
		smsMessageServiceBL.sendMessage(smsMessageDTO);
	}

	@Override
	public boolean sendSingleMessage(SMSSingleMessageDTO smsSingleMessage) {
		String mobile = smsSingleMessage.getMobile();
		String content = smsSingleMessage.getContent();
		smsMessageServiceBL.validate(mobile, content);
		return smsMessageServiceBL.sendMessage(smsSingleMessage);
	}

	@Override
	public void sendMessageFromV1(SMSMessageDTO smsMessageDTO) {
		List<String> mobileList = smsMessageDTO.getMobileList();
		String content = smsMessageDTO.getContent();
		smsMessageServiceBL.validate(mobileList, content);
		smsMessageServiceBL.sendMessageFromV1(smsMessageDTO);
	}

}
