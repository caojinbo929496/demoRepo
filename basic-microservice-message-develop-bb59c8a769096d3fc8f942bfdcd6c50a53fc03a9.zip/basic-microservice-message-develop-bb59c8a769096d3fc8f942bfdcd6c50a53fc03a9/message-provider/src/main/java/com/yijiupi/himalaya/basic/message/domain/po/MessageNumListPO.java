package com.yijiupi.himalaya.basic.message.domain.po;

import java.util.Date;

public class MessageNumListPO {
    private Integer id;

    private String mobileno;

    private Byte listtype;

    private Date createtime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        this.mobileno = mobileno == null ? null : mobileno.trim();
    }

    public Byte getListtype() {
        return listtype;
    }

    public void setListtype(Byte listtype) {
        this.listtype = listtype;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }
}