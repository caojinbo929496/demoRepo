package com.yijiupi.himalaya.basic.message.domain.bo;

import java.sql.Timestamp;

public class BlackListResult {

	private Integer count;
	
	private Integer Id;
	
	private String MobileNo;
	
	private Timestamp CreateTime;

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getMobileNo() {
		return MobileNo;
	}

	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}

	public Timestamp getCreateTime() {
		return CreateTime;
	}

	public void setCreateTime(Timestamp createTime) {
		CreateTime = createTime;
	}

	
}
