package com.yijiupi.himalaya.basic.message.domain.bl;

import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;
import com.yijiupi.himalaya.basic.message.enums.PushAPPType;
import com.yijiupi.himalaya.basic.message.enums.PushType;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Collections;

@Service
public class PushMessageBL {

	@Autowired
	private RabbitTemplate rabbitTemplate;
	
	@Value("${spring.rabbitmq.sendPushMessageQueue}")
	private String yjp_Message_Push;

	public void pushAppMessage(PushMessageDTO pushMessage) {
		rabbitTemplate.convertAndSend(yjp_Message_Push,"", pushMessage);
	}

}
