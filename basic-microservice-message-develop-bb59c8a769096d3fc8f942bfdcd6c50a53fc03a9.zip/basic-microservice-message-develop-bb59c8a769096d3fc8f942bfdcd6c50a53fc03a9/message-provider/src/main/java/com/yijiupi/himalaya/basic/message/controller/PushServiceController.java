package com.yijiupi.himalaya.basic.message.controller;

import com.yijiupi.himalaya.basic.message.controller.model.PushFromV1DTO;
import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageDTO;
import com.yijiupi.himalaya.basic.message.service.IPushMessageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

/**
 * 推送接口
 */
@RestController
public class PushServiceController {
    private static final Logger LOGGER = LoggerFactory.getLogger(PushServiceController.class);

    @Autowired
    private IPushMessageService iPushMessageService;

    /**
     * 单条推送
     */
    @RequestMapping(value = "/push/pushAppMessage", method = RequestMethod.POST)
    public BaseResult sendMessage(@RequestBody PushFromV1DTO pushFromV1DTO) {
        try {
            iPushMessageService.pushAppMessage(pushFromV1DTO.buildPushMessageDTO());
        } catch (Exception e) {
            LOGGER.error("jiupiV1调用推送接口失败，用户Id：{}，短信内容：{}", pushFromV1DTO.getUserIdv1(), pushFromV1DTO.getContent());
            return BaseResult.getFailedResult(e);
        }
        return BaseResult.getSuccessResult();
    }
}
