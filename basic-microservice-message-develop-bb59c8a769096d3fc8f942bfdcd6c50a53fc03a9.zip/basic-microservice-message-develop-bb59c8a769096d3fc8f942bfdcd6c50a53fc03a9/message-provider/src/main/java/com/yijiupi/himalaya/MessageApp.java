package com.yijiupi.himalaya;

import java.util.concurrent.CountDownLatch;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RestController;

/**
 * 发送短信的微服务
 */
@MapperScan(basePackages = "com.yijiupi.himalaya.basic.message.domain.dao")
@SpringBootApplication
public class MessageApp {
	/**
	 * 短信微服务主线程入口
	 * 
	 * @param args
	 * @throws InterruptedException
	 * @return: void
	 */
	public static void main(String[] args) throws InterruptedException {

		SpringApplication app = new SpringApplication(MessageApp.class);
		app.run(args);
	}
}
