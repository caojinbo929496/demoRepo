package com.yijiupi.himalaya.basic.message.controller;

public class BaseResult {

	private boolean success;
	private String message;
	private String desc;
	
	public static BaseResult getSuccessResult() {
		return new BaseResult(true, null, null);
	}
	
	public static BaseResult getFailedResult(Exception e) {
		return new BaseResult(false, null, e.getMessage());
	}

	public BaseResult() {
		
	}

	public BaseResult(boolean success, String message, String desc) {
		super();
		this.success = success;
		this.message = message;
		this.desc = desc;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

}
