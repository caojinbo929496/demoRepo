package com.yijiupi.himalaya.basic.message.domain.dao;

import java.util.List;

import com.yijiupi.himalaya.basic.message.domain.po.MessagePO;

public interface MessagePOMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(MessagePO record);

    int insertSelective(MessagePO record);

    int updateByPrimaryKeySelective(MessagePO record);

    int updateByPrimaryKey(MessagePO record);
    
    
    List<MessagePO> findByMobile(String mobile);
    
}