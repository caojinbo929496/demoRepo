package com.yijiupi.himalaya.basic.message.domain.converter;

import com.yijiupi.himalaya.basic.message.domain.bo.BlackListResult;
import com.yijiupi.himalaya.basic.message.dto.Blacklist;

public class BlackListResultConverter {

	public static Blacklist blackListResultToDTO(BlackListResult result){
		Blacklist blackList = new Blacklist();
		blackList.setCreateTime(result.getCreateTime());
		blackList.setId(result.getId());
		blackList.setMobile(result.getMobileNo());
		return blackList;
	}
	
}
