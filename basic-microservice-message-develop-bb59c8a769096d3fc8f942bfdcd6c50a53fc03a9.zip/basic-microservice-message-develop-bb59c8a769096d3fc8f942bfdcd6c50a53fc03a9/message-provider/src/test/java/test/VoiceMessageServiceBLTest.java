package test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.yijiupi.himalaya.MessageApp;
import com.yijiupi.himalaya.basic.message.dto.VoiceMessageDTO;
import com.yijiupi.himalaya.basic.message.service.IVoiceMessageService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = MessageApp.class)
public class VoiceMessageServiceBLTest {

	@Autowired
	private IVoiceMessageService voiceMessageService;
	
	@Test
	public void sendMessageTest(){
		VoiceMessageDTO voiceMessageDTO = new VoiceMessageDTO();
		voiceMessageDTO.setMobile("12345678910");
		voiceMessageDTO.setContent("1234");
		voiceMessageService.sendMessage(voiceMessageDTO);
	}
	
}
