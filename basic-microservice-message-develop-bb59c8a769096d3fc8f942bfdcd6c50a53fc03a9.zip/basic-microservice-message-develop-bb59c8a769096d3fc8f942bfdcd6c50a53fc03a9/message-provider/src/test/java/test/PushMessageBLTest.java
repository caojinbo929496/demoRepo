package test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.yijiupi.himalaya.MessageApp;
import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;
import com.yijiupi.himalaya.basic.message.service.IPushMessageService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = MessageApp.class)
public class PushMessageBLTest {

	Logger logger = LoggerFactory.getLogger(PushMessageBLTest.class);

	@Autowired
	private IPushMessageService pushMessageService;

	@Test
	public void pushAppMessageTest(){
		PushMessageDTO pushMessageDTO = new PushMessageDTO();
		pushMessageService.pushAppMessage(pushMessageDTO);
	}
	
	@Test
	public void PushMessageBLTest() {
		PushMessageDTO pushMessageDTO = new PushMessageDTO();

		pushMessageService.pushAppMessage(pushMessageDTO);
	}

}
