package test;

import com.yijiupi.himalaya.MessageApp;
import com.yijiupi.himalaya.base.search.PagerCondition;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageDTO;
import com.yijiupi.himalaya.basic.message.dto.SMSSingleMessageDTO;
import com.yijiupi.himalaya.basic.message.service.ISMSMessageService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = MessageApp.class)
public class SMSMessageServiceBLTest {
   
	@Autowired
	private ISMSMessageService smsMessageService;
	
	@Test
	public void addBlacklistTest(){
		smsMessageService.addBlacklist("10101010101");
	}
	
	@Test
	public void findBlacklistTest(){
		PagerCondition pagerCondition = new PagerCondition();
		pagerCondition.setCurrentPage(1);
		pagerCondition.setPageSize(10);
		smsMessageService.findBlacklist("10101010101", pagerCondition);
		
	}
	
	@Test
	public void findSMSMessageListByMobileTest(){
		smsMessageService.findSMSMessageListByMobile("10101010101");
	}
	
	@Test
	public void removeBlacklistTest(){
		smsMessageService.removeBlacklist(77);
	}
	
	@Test
	public void sendMessageTest(){
		SMSMessageDTO smsMessageDTO = new SMSMessageDTO();
		smsMessageDTO.setContent("test sendMessageTest");
		List<String> mobileList = new ArrayList<>();
		mobileList.add("12345");
		mobileList.add("10101010101");
		smsMessageDTO.setMobileList(mobileList);
		smsMessageService.sendMessage(smsMessageDTO);
	}
	
	@Test
	public void sendSingleMessageTest(){
		SMSSingleMessageDTO smsSingleMessage = new SMSSingleMessageDTO();
		smsSingleMessage.setContent("test sendSingleMessage");
		smsSingleMessage.setMobile("10101010101");
		smsMessageService.sendSingleMessage(smsSingleMessage);
	}
   
}
