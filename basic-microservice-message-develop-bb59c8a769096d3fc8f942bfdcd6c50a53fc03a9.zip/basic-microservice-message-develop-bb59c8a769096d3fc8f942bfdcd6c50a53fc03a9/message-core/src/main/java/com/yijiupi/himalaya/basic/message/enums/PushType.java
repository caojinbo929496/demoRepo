/**
 * Copyright © 2016 北京易酒批电子商务有限公司. All rights reserved.
 */
package com.yijiupi.himalaya.basic.message.enums;

/**
 * 推送类型，主要区分单个推送，全部推送，tag推送
 *
 * @author: 徐净睿
 * @date: 2016年6月28日
 */
public enum PushType {
    城市推送(1), 全国推送(2), 用户推送(0);

    public Integer value;

    private PushType(Integer value) {
        this.value = value;
    }

    @Override
    public String toString() {

        return String.valueOf(this.value);
    }
}
