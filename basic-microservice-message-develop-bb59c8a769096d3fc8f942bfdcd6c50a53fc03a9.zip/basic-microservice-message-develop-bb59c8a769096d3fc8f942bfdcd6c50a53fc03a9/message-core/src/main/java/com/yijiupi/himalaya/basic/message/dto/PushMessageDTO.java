package com.yijiupi.himalaya.basic.message.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.yijiupi.himalaya.base.enums.MallAppType;
import com.yijiupi.himalaya.basic.message.enums.PushAPPType;
import com.yijiupi.himalaya.basic.message.enums.PushType;

/**
 * 推送消息.
 * 
 * @author: mxyong
 * @date: 2016年8月30日 下午10:28:04
 */
public class PushMessageDTO implements Serializable {

	private static final long serialVersionUID = -7347306726132778592L;

	private String content;
	/**
	 * 附加字段
	 */
	private Map<String, String> extras;
	private PushAPPType pushAPPType;
	private PushType pushType;
	private List<String> tagOrIdList;
	private Boolean contentAvailable = false;

	/**
	 * 所属APP，默认酒批
	 */
	private MallAppType mallAppType = MallAppType.酒批;

	public boolean isContentAvailable() {
		return contentAvailable;
	}

	public void setContentAvailable(boolean contentAvailable) {
		this.contentAvailable = contentAvailable;
	}

	public String getContent() {
		return this.content;
	}

	public PushAPPType getPushAPPType() {
		return pushAPPType;
	}

	public PushType getPushType() {
		return pushType;
	}

	public List<String> getTagOrIdList() {
		return this.tagOrIdList;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setPushAPPType(PushAPPType pushAPPType) {
		this.pushAPPType = pushAPPType;
	}

	public void setPushType(PushType pushType) {
		this.pushType = pushType;
	}

	public void setTagOrIdList(List<String> tagOrIdList) {
		this.tagOrIdList = tagOrIdList;
	}

	public MallAppType getMallAppType() {
		return mallAppType;
	}

	public Map<String, String> getExtras() {
		return extras;
	}

	public void setExtras(Map<String, String> extras) {
		this.extras = extras;
	}

	public void setMallAppType(MallAppType mallAppType) {
		this.mallAppType = mallAppType;
	}
}