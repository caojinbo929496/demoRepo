/**
 * Copyright © 2016 北京易酒批电子商务有限公司. All rights reserved.
 */
package com.yijiupi.himalaya.basic.message.dto;

import com.yijiupi.himalaya.base.enums.MallAppType;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * 要发送短信消息.
 *
 * @author: mxyong
 * @date: 2016年8月24日 下午1:54:12
 */
public class SMSMessageDTO implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1225656599921347482L;
    /**
     * 短信内容；必填
     */
    private String content;
    /**
     * 发送短信的手机号码，多个手机号码用英文逗号隔开
     */
    private List<String> mobileList = new ArrayList<>();

    /**
     * 所属APP，默认酒批
     */
    private MallAppType mallAppType = MallAppType.酒批;

    public String getContent() {

        return content;
    }

    public void setContent(String content) {

        this.content = content;
    }

    public List<String> getMobileList() {

        return mobileList;
    }

    public void setMobileList(List<String> mobileList) {

        this.mobileList = mobileList;
    }

    public MallAppType getMallAppType() {
        return mallAppType;
    }

    public void setMallAppType(MallAppType mallAppType) {
        this.mallAppType = mallAppType;
    }
}
