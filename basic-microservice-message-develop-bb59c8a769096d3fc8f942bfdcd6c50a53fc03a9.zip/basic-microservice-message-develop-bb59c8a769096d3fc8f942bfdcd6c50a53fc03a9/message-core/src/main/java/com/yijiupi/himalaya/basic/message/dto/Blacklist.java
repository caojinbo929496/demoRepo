/**
 * Copyright © 2016 北京易酒批电子商务有限公司. All rights reserved.
 */
package com.yijiupi.himalaya.basic.message.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 短信发送黑名单号码.
 *
 * @author: mxyong
 * @date: 2016年8月24日 下午1:57:22
 */
public class Blacklist implements Serializable {

    /**
     * 添加时间.
     */
    private Date createTime;
    /**
     * 编号.
     */
    private Integer id;
    /**
     * 黑白名单的字段内容：手机号
     */
    private String mobile;

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

}
