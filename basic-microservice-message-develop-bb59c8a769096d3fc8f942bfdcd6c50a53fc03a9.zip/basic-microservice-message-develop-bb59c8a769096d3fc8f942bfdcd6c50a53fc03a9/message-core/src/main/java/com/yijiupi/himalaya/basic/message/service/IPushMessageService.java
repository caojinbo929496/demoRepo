/**
 * Copyright © 2016 北京易酒批电子商务有限公司. All rights reserved.
 */
package com.yijiupi.himalaya.basic.message.service;

import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;

/**
 * 推送消息接口定义
 * 
 * @author: mxyong
 * @date: 2016年8月30日 下午10:25:48
 */
public interface IPushMessageService {

	/**
	 * 推送消息
	 *
	 * @param pushMessageDTO
	 * @return
	 * @return: String
	 */
	void pushAppMessage(PushMessageDTO pushMessage);
}
