/**
 * Copyright © 2016 北京易酒批电子商务有限公司. All rights reserved.
 */
package com.yijiupi.himalaya.basic.message.dto;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import com.yijiupi.himalaya.base.enums.MallAppType;
import com.yijiupi.himalaya.basic.message.enums.MessageBusinessType;
import com.yijiupi.himalaya.basic.message.enums.PushAPPType;
import com.yijiupi.himalaya.basic.message.enums.PushType;

/**
 * 推送消息.
 *
 * @author: mxyong
 * @date: 2016年8月24日 下午2:02:22
 */
public class NotificationMessageDTO implements Serializable {
	/**
	 * 按城市推送时的城市编号.
	 */
	private Integer cityId;
	/**
	 * 推送内容.
	 */
	private String content;
	private MessageBusinessType messageBusinessType;
	/**
	 * 选填，当要接收的手机号与userId不对应的时候填此属性.
	 */
	private List<String> mobileList;
	private PushAPPType pushAPPType = PushAPPType.E_JIU_PI;
	private PushType pushType;
	/**
	 * 要推送的用户列表
	 */
	private List<Integer> userIdList;

	/**
	 * 商城App类型
	 */
	private MallAppType mallAppType;

	/**
	 * 仅用于Dubbo反序列化使用
	 */
	public NotificationMessageDTO() {}

	private NotificationMessageDTO(MessageBusinessType messageBusinessType, String content,PushType pushType) {
		this.messageBusinessType = messageBusinessType;
		this.content = content;
		this.pushType = pushType;
	}

	/**
	 * 构建发放范围为城市的NotificationMessage
	 * @param messageBusinessType 业务类型
	 * @param cityId 城市ID
	 * @param content 内容
	 * @return
	 */
	public static NotificationMessageDTO buildCityMessage(MessageBusinessType messageBusinessType, String content,Integer cityId) {
		NotificationMessageDTO notificationMessageDTO = new NotificationMessageDTO(messageBusinessType,content,PushType.城市推送);
		notificationMessageDTO.cityId = cityId;
		return notificationMessageDTO;
	}

	/**
	 * 构建发放范围为全国的NotificationMessage
	 * @param messageBusinessType
	 * @param content
	 * @return
	 */
	public static NotificationMessageDTO buildGlobalMessage(MessageBusinessType messageBusinessType,String content) {
		return new NotificationMessageDTO(messageBusinessType,content,PushType.全国推送);
	}

	/**
	 * 构建发放范围为多个用户的NotificationMessage
	 * @param messageBusinessType
	 * @param content
	 * @param userIdList
	 * @return
	 */
	public static NotificationMessageDTO buildUserMessage(MessageBusinessType messageBusinessType,String content,List<Integer> userIdList) {
		NotificationMessageDTO notificationMessageDTO = new NotificationMessageDTO(messageBusinessType,content,PushType.用户推送);
		notificationMessageDTO.userIdList = userIdList;
		return notificationMessageDTO;
	}

	/**
	 * 构建发放范围为多个用户的NotificationMessage
	 * @param messageBusinessType
	 * @param content
	 * @param userIdList
	 * @return
	 */
	public static NotificationMessageDTO buildUserMessage(MessageBusinessType messageBusinessType,String content,List<Integer> userIdList,List<String> mobileList) {
		NotificationMessageDTO notificationMessageDTO = new NotificationMessageDTO(messageBusinessType,content,PushType.用户推送);
		notificationMessageDTO.userIdList = userIdList;
		notificationMessageDTO.mobileList = mobileList;
		return notificationMessageDTO;
	}

	/**
	 * 构建发放范围为单个用户的NotificationMessage
	 * @param messageBusinessType
	 * @param content
	 * @param userId
	 * @return
	 */
	public static NotificationMessageDTO buildUserMessage(MessageBusinessType messageBusinessType,String content,Integer userId) {
		NotificationMessageDTO notificationMessageDTO = new NotificationMessageDTO(messageBusinessType,content,PushType.用户推送);
		notificationMessageDTO.userIdList = Arrays.asList(userId);
		return notificationMessageDTO;
	}

	/**
	 * 构建发放范围为单个用户的NotificationMessage
	 * @param messageBusinessType
	 * @param content
	 * @param userId
	 * @return
	 */
	public static NotificationMessageDTO buildUserMessage(MessageBusinessType messageBusinessType,String content,Integer userId,String mobileNO) {
		NotificationMessageDTO notificationMessageDTO = new NotificationMessageDTO(messageBusinessType,content,PushType.用户推送);
		notificationMessageDTO.userIdList = Arrays.asList(userId);
		notificationMessageDTO.mobileList = Arrays.asList(mobileNO);
		return notificationMessageDTO;
	}

	public Integer getCityId() {
		return cityId;
	}

	public String getContent() {
		return content;
	}

	public MessageBusinessType getMessageBusinessType() {
		return messageBusinessType;
	}

	public List<String> getMobileList() {
		return mobileList;
	}

	public PushAPPType getPushAPPType() {
		return pushAPPType;
	}

	public PushType getPushType() {
		return pushType;
	}

	public List<Integer> getUserIdList() {
		return userIdList;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void setMessageBusinessType(MessageBusinessType messageBusinessType) {
		this.messageBusinessType = messageBusinessType;
	}

	public void setMobileList(List<String> mobileList) {
		this.mobileList = mobileList;
	}

	public void setPushAPPType(PushAPPType pushAPPType) {
		this.pushAPPType = pushAPPType;
	}

	public void setPushType(PushType pushType) {
		this.pushType = pushType;
	}

	public void setUserIdList(List<Integer> userIdList) {
		this.userIdList = userIdList;
	}

	public MallAppType getMallAppType() {
		return mallAppType;
	}

	public void setMallAppType(MallAppType mallAppType) {
		this.mallAppType = mallAppType;
	}
}
