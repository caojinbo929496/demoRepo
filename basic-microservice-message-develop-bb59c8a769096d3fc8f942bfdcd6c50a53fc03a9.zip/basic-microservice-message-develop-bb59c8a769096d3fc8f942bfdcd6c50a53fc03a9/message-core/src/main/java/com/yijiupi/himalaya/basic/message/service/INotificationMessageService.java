package com.yijiupi.himalaya.basic.message.service;

import com.yijiupi.himalaya.basic.message.dto.NotificationMessageDTO;

/**
 * 由系统设置的消息推送.
 * 
 * @author: mxyong
 * @date: 2016年8月30日 下午9:43:17
 */
public interface INotificationMessageService {

	void sendNotificationMessage(NotificationMessageDTO notificationMessageDTO);

}
