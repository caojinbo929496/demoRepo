package com.yijiupi.himalaya.basic.message.enums;

public enum MessageBusinessType {
	订单审核不通过提醒(3), 订单审核通过提醒(2), 订单使用红包提醒(5), 订单完成送优惠券和红包(4), 定向发放红包(7), 定向发放优惠券(8), 短信验证码(15), 红包过期提醒(9), 红包激励活动发放提醒(
			0), 会员消息推送_广告(
					12), 会员消息推送_活动(13), 会员注册消息提醒(6), 经营内参(14), 库存预警(16), 投诉和找货反馈消息(11), 优惠券过期提醒(10), 优惠券激励活动发放提醒(1);

	private Integer value;

	private MessageBusinessType(Integer value) {
		this.value = value;
	}

	public Integer getValue() {
		return this.value;
	}

	@Override
	public String toString() {
		return String.valueOf(this.value);
	}
}