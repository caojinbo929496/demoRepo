package com.yijiupi.himalaya.basic.message.service;

import com.yijiupi.himalaya.basic.message.dto.VoiceMessageDTO;

public interface IVoiceMessageService {
    void sendMessage(VoiceMessageDTO voiceMessage);
}
