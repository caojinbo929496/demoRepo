/**
 * Copyright © 2016 北京易酒批电子商务有限公司. All rights reserved.
 */
package com.yijiupi.himalaya.basic.message.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 短信发送历史记录.
 *
 * @author: mxyong
 * @date: 2016年8月24日 下午1:53:55
 */
public class SMSMessageHistory implements Serializable {

	/**
	 * 短信内容，必填项
	 */
	private String content;
	/**
	 * 发送时间
	 */
	private Date createTime;
	/**
	 * 短信发送失败的错误描述信息
	 */
	private String errorMessage;
	/**
	 * 扩展信息
	 */
	private String extras;

	/**
	 * 短信发送是否成功的状态
	 */
	private Boolean isSucess;
	/**
	 * 手机号码，必填项
	 */
	private String mobile;

	/**
	 * 获取短信内容，必填项
	 */
	public String getContent() {

		return content;
	}

	public Date getCreateTime() {

		return createTime;
	}

	public String getErrorMessage() {

		return errorMessage;
	}

	public String getExtras() {

		return extras;
	}

	public Boolean getIsSucess() {

		return isSucess;
	}

	/**
	 * 获取手机号码，必填项
	 */
	public String getmobile() {

		return mobile;
	}

	/**
	 * 设置短信内容，必填项
	 */
	public void setContent(String content) {

		this.content = content;
	}

	public void setCreateTime(Date createTime) {

		this.createTime = createTime;
	}

	public void setErrorMessage(String errorMessage) {

		this.errorMessage = errorMessage;
	}

	public void setExtras(String extras) {

		this.extras = extras;
	}

	public void setIsSucess(Boolean isSucess) {

		this.isSucess = isSucess;
	}

	/**
	 * 设置手机号码，必填项
	 */
	public void setmobile(String mobile) {

		this.mobile = mobile;
	}

}
