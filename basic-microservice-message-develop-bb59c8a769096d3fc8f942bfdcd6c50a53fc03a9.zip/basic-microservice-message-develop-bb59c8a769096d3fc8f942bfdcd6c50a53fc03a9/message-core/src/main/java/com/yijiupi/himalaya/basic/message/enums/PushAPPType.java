package com.yijiupi.himalaya.basic.message.enums;

public enum PushAPPType {
	E_JIU_PI(1001), E_JIU_PI_BROKER(1004), E_JIU_PI_DEALER(1003), E_JIU_PI_DELIVERY(1002),
	RETAIL_POS(1005), RETAIL_BOSS(1006);

	private Integer value;

	private PushAPPType(Integer value) {
		this.value = value;
	}

	public Integer getValue() {
		return this.value;
	}
}