/**
 * Copyright © 2016 北京易酒批电子商务有限公司. All rights reserved.
 */
package com.yijiupi.himalaya.basic.message.service;

import com.yijiupi.himalaya.base.search.PageList;
import com.yijiupi.himalaya.base.search.PagerCondition;
import com.yijiupi.himalaya.basic.message.dto.Blacklist;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageDTO;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageHistory;
import com.yijiupi.himalaya.basic.message.dto.SMSSingleMessageDTO;

import java.util.List;

public interface ISMSMessageService {

    /**
     * 添加短信发送手机黑名单
     */
    void addBlacklist(String mobile);

    /**
     * 按条件查询黑名单列表
     */
    PageList<Blacklist> findBlacklist(String mobile, PagerCondition pagerCondition);

    /**
     * 查询指定手机号码由平台发出的近50条短信历史记录.
     *
     * @param mobile
     * @return
     * @return List<SMSMessage>
     */
    List<SMSMessageHistory> findSMSMessageListByMobile(String mobile);

    /**
     * 通过主键删除手机短信黑名单.
     *
     * @param id
     * @return: void
     */
    void removeBlacklist(Integer id);

    /**
     * 对一批手机发送短信
     *
     * @param smsMessageDTO
     */
    void sendMessage(SMSMessageDTO smsMessageDTO);

    /**
     * 对单个手机发送短信
     */
    boolean sendSingleMessage(SMSSingleMessageDTO smsSingleMessage);

    /**
     * 群发来自1.0系统的短信，只用hfwy通道
     */
    void sendMessageFromV1(SMSMessageDTO smsMessageDTO);
}
