package com.yijiupi.himalaya.basic.message.dto;

import com.yijiupi.himalaya.base.enums.MallAppType;

import java.io.Serializable;

public class VoiceMessageDTO implements Serializable {
    /**
     * 短信内容；必填
     */
    private String content;
    /**
     * 发送短信的手机号码
     */
    private String mobile;

    /**
     * 所属APP，默认酒批
     */
    private MallAppType mallAppType = MallAppType.酒批;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public MallAppType getMallAppType() {
        return mallAppType;
    }

    public void setMallAppType(MallAppType mallAppType) {
        this.mallAppType = mallAppType;
    }
}
