package com.yijiupi.himalaya.message.provider.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.yijiupi.himalaya.basic.message.dto.SMSMessageDTO;
import com.yijiupi.himalaya.basic.message.dto.SMSSingleMessageDTO;
import com.yijiupi.himalaya.basic.messagesender.dto.SMSMessageSenderDTO;
import com.yijiupi.himalaya.basic.messagesender.service.ISendSMSMessageService;
import com.yijiupi.himalaya.basic.messagesender.service.ISendV1SMSMessageService;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component
public class SMSMessageService {
    @Reference
    ISendSMSMessageService sendSMSMessageService;

    @Reference
    private ISendV1SMSMessageService iSendV1SMSMessageService;

    public void sendMessage(SMSMessageDTO message) {
        sendSMSMessageService.sendMessage(convert(message));
    }

    public void sendMessageFromV1(SMSMessageDTO message) {
        iSendV1SMSMessageService.sendMessage(convert(message));
    }


    public void sendSingleMessage(SMSSingleMessageDTO message) {
        sendSMSMessageService.sendMessage(convert(message));
    }

    private SMSMessageSenderDTO convert(SMSSingleMessageDTO messageDTO) {
        SMSMessageSenderDTO senderDTO = new SMSMessageSenderDTO();
        senderDTO.setMallAppType(messageDTO.getMallAppType());
        senderDTO.setContent(messageDTO.getContent());
        senderDTO.setMobileList(Collections.singletonList(messageDTO.getMobile()));
        return senderDTO;
    }

    private SMSMessageSenderDTO convert(SMSMessageDTO messageDTO) {
        SMSMessageSenderDTO senderDTO = new SMSMessageSenderDTO();
        senderDTO.setMallAppType(messageDTO.getMallAppType());
        senderDTO.setContent(messageDTO.getContent());
        senderDTO.setMobileList(messageDTO.getMobileList());
        return senderDTO;
    }
}
