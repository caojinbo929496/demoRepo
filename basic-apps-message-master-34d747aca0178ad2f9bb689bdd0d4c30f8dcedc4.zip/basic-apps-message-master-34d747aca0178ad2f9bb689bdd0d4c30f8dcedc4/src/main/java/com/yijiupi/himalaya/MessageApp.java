package com.yijiupi.himalaya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;

/**
 * 短信消息队列服务
 *
 * @author: 徐净睿
 * @date: 2016年6月22日 上午10:55:44
 */
@SpringBootApplication
public class MessageApp {

    /**
     * 短信消息队列服务的主线程
     *
     * @param args
     * @throws IOException
     * @return: void
     */
    public static void main(String[] args) throws IOException {

        // ActiveMQ序列化包
        System.setProperty("org.apache.activemq.SERIALIZABLE_PACKAGES", "*");
        SpringApplication app = new SpringApplication(MessageApp.class);
        app.setWebEnvironment(false);// 不启动WEB 环境
        app.run(args);
    }
}
