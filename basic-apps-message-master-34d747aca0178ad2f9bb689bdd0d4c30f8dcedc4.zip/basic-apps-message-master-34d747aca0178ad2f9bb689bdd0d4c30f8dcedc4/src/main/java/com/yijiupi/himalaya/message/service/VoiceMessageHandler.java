package com.yijiupi.himalaya.message.service;

import com.google.gson.Gson;
import com.yijiupi.himalaya.basic.message.dto.VoiceMessageDTO;
import com.yijiupi.himalaya.message.provider.service.impl.VoiceMessageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

/**
 * 语音消息处理.
 *
 * @author: mxyong
 * @date: 2016年8月30日 上午9:35:15
 */
@Component
public class VoiceMessageHandler {
    private static final Logger logger = LoggerFactory.getLogger(VoiceMessageHandler.class);

    @Autowired
    private VoiceMessageService messageService;
    
    @Autowired
    private Gson gson;

    /**
     * 监听语音消息队列的数据，语音消息发送接口发送.
     *
     * @param messageDTO
     * @return: void
     */
    @JmsListener(destination = "${spring.activemq.sendvoicemessagequeue}", concurrency = "10")
    public void handlerMessage(VoiceMessageDTO message) {
    	logger.info("语音验证码消息队列收到数据：" + gson.toJson(message));
        messageService.sendMessage(message);
    }
}
