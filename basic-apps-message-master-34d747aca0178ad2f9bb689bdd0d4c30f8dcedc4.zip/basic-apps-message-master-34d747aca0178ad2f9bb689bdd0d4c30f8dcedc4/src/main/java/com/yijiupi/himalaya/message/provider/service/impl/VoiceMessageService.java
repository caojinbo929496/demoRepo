package com.yijiupi.himalaya.message.provider.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.yijiupi.himalaya.basic.message.dto.VoiceMessageDTO;
import com.yijiupi.himalaya.basic.messagesender.dto.VoiceMessageSenderDTO;
import com.yijiupi.himalaya.basic.messagesender.service.ISendVoiceMessageService;
import org.springframework.stereotype.Component;

/**
 * 语音消息发送.
 *
 * @author: mxyong
 * @date: 2016年8月30日 上午9:42:28
 */
@Component
public class VoiceMessageService {
    @Reference
    ISendVoiceMessageService sendVoiceMessageService;

    public void sendMessage(VoiceMessageDTO message) {
        sendVoiceMessageService.sendMessage(convert(message));
    }

    private VoiceMessageSenderDTO convert(VoiceMessageDTO message) {
        VoiceMessageSenderDTO senderDTO = new VoiceMessageSenderDTO();
        senderDTO.setContent(message.getContent());
        senderDTO.setMallAppType(message.getMallAppType());
        senderDTO.setMobile(message.getMobile());
        return senderDTO;
    }
}
