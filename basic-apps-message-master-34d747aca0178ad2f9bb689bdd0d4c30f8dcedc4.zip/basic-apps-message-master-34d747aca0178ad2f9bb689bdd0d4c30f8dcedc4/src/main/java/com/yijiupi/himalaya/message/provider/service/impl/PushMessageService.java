package com.yijiupi.himalaya.message.provider.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;
import com.yijiupi.himalaya.basic.message.enums.PushAPPType;
import com.yijiupi.himalaya.basic.message.enums.PushType;
import com.yijiupi.himalaya.basic.messagesender.dto.PushMessageSenderDTO;
import com.yijiupi.himalaya.basic.messagesender.service.ISendPushMessageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class PushMessageService {

    private static final Logger LOGGER = LoggerFactory.getLogger(PushMessageService.class);

    @Reference(timeout = 30000)
    ISendPushMessageService sendPushMessageService;

    public void pushAppMessage(PushMessageDTO message) {
        try {
            sendPushMessageService.sendMessage(convert(message));
        } catch (Exception e) {
            LOGGER.error("推送发生异常。", e);
        }
    }

    private PushMessageSenderDTO convert(PushMessageDTO messageDTO) {
        PushMessageSenderDTO senderDTO = new PushMessageSenderDTO();
        senderDTO.setContent(messageDTO.getContent());
        senderDTO.setMallAppType(messageDTO.getMallAppType());
        PushAPPType pushAPPType = messageDTO.getPushAPPType();
        if (pushAPPType != null)
            senderDTO.setPushAPPType(pushAPPType.getValue());
        PushType pushType = messageDTO.getPushType();
        if (pushType != null)
            senderDTO.setPushType(pushType.value);
        senderDTO.setTagOrIdList(messageDTO.getTagOrIdList());
        return senderDTO;
    }
}
