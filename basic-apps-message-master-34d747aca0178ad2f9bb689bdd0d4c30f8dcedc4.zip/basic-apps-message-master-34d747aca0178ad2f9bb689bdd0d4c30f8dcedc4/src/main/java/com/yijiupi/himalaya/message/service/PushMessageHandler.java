package com.yijiupi.himalaya.message.service;

import com.yijiupi.himalaya.basic.message.dto.PushMessageDTO;
import com.yijiupi.himalaya.message.provider.service.impl.PushMessageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

/**
 * 推送消息处理.
 *
 * @author: mxyong
 * @date: 2016年8月30日 上午9:19:24
 */
@Component
public class PushMessageHandler {

    private static final Logger logger = LoggerFactory.getLogger(PushMessageHandler.class);
    @Autowired
    PushMessageService pushMessageService;

    /**
     * 监听推送消息队列的数据，调用推送接口发送消息.
     *
     * @param messageDTO
     * @return: void
     */
    @JmsListener(destination = "${spring.activemq.sendpushmessagequeue}", concurrency = "10")
    public void handlerMessage(PushMessageDTO message) {
        pushMessageService.pushAppMessage(message);
    }

}
