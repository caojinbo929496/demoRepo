package com.offbytwo.jenkins.model;

public class BuildLogs extends BaseModel {

    /**
     * 追加的日志内容
     */
    private String text;

    /**
     * 下次调用的起点
     */
    private Integer textSize;

    /**
     * 是否有更多日志
     */
    private boolean hasMore;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Integer getTextSize() {
        return textSize;
    }

    public void setTextSize(Integer textSize) {
        this.textSize = textSize;
    }

    public boolean isHasMore() {
        return hasMore;
    }

    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }
}
