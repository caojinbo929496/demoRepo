package com.offbytwo.jenkins.model;

public class ExtractHeader extends BaseModel {

    private String location;

    public void setLocation(String value) {
        location = value;
    }

    public String getLocation() {
        return location;
    }

}
