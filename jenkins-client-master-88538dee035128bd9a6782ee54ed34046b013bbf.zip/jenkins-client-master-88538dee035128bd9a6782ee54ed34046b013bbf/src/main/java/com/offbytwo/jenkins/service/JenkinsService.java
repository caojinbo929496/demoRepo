package com.offbytwo.jenkins.service;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.offbytwo.jenkins.client.JenkinsHttpClient;
import com.offbytwo.jenkins.client.util.EncodingUtils;
import com.offbytwo.jenkins.helper.JenkinsVersion;
import com.offbytwo.jenkins.model.*;
import com.offbytwo.jenkins.model.stage.StagesBuild;
import org.apache.http.client.HttpResponseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class JenkinsService {
    private static final Logger LOGGER = LoggerFactory.getLogger(JenkinsService.class);

    /**
     * 根目录
     */
    public static final List<String> ROOT_FOLDER = Collections.singletonList("/");

    private final JenkinsHttpClient client;


    public JenkinsService(String serverUri, String username, String passwordOrToken)  {
        try {
            this.client = new JenkinsHttpClient(new URI(serverUri), username, passwordOrToken);
            LOGGER.info("Jenkins 客户端初始化成功, URL: " + serverUri);
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("URISyntax:" + serverUri, e);
        }
    }

    /**
     * 是否正在运行
     */
    public boolean isRunning() {
        try {
            client.get("/");
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public JenkinsVersion getVersion() {
        if (client.getJenkinsVersion().isEmpty()) {
            // Force a request to get at least once
            // HttpHeader
            isRunning();
        }
        return new JenkinsVersion(client.getJenkinsVersion());
    }

    /**
     * 获取某目录下的所有Job
     */
    public Map<String, Job> getJobs(List<String> folderNames) throws IOException {
        String path = toBasePath(folderNames);
        List<Job> jobs = client.get(path, MainView.class).getJobs();
        return Maps.uniqueIndex(jobs, new Function<Job, String>() {
            @Override
            public String apply(Job job) {
                job.setClient(client);
                return job.getName();
            }
        });
    }

    /**
     * 获取指定项目的详情
     */
    public JobWithDetails getJob(List<String> folderNames, String jobName) throws IOException {
        jobName = jobName.replace("/", "");
        String path = toJobBaseUrl(folderNames, jobName);
        JobWithDetails job = client.get(path, JobWithDetails.class);
        job.setClient(client);
        return job;
    }


        /**
         * 检查目录或者Job是否存在
         */
    public boolean existJob(List<String> jobNames) throws IOException {
        try {
            getJobs(jobNames);
            return true;
        } catch (HttpResponseException e) {
            if (e.getStatusCode() == 404) {
                return false;
            }
            throw e;
        }
    }

    /**
     * 在指定目录下面创建一个新目录
     * @param folderName 新目录名字
     */
    private void createFolder(List<String> folderNames, String folderName) throws IOException {
        ImmutableMap<String, String> params = ImmutableMap.of("mode", "com.cloudbees.hudson.plugins.folder.Folder",
                "name", EncodingUtils.encodeParam(folderName), "from", "", "Submit", "OK");
        client.post_form(toBasePath(folderNames) + "createItem?", params, false);
        LOGGER.info("在{}下创建目录：{}成功", folderNames, folderName);
    }

    /**
     * 递归创建目录，如上级目录不存在则创建
     */
    public void createFolderForce(List<String> folderNames, String folderName) throws IOException {
        createIfNot(folderNames);
        createFolder(folderNames, folderName);
    }

    public void createJobForce(List<String> folderNames, String jobName, String jobXml) throws IOException {
        createIfNot(folderNames);
        client.post_xml(toBasePath(folderNames) + "createItem?name=" + EncodingUtils.encodeParam(jobName), jobXml.trim(), false);
        LOGGER.info("在{}下创建Job：{}成功", folderNames, jobName);
    }

    /**
     * 删除目录
     */
    public void deleteJob(List<String> jobNames) throws IOException {
        client.post(toBasePath(jobNames) + "/doDelete", false);
    }

    public QueueReference buildJob(List<String> folderNames, String jobName) throws IOException {
        return getJob(folderNames, jobName).build();
    }

    public QueueReference buildJob(List<String> folderNames, String jobName, Map<String, String> params) throws IOException {
        return getJob(folderNames, jobName).build(params);
    }


    public Queue getQueue() throws IOException {
        return client.get("queue/?depth=1", Queue.class);
    }

    private QueueItem getQueueItem(QueueReference ref) throws IOException {
        String url = ref.getQueueItemUrlPart();
        QueueItem queueItem = client.get(url, QueueItem.class);
        queueItem.setClient(client);
        return queueItem;
    }

    /**
     * 获取最后一次构建状态
     */
    public BuildWithDetails getLastBuild(List<String> folderNames, String jobName) throws IOException {
        JobWithDetails job = getJob(folderNames, jobName);
        return job.getLastBuild().details();
    }

    private JobWithDetails getJob(QueueItem queueItem) throws IOException {
        String url = queueItem.getTask().getUrl();
        String[] jobs = url.split("/job/");
        int length = jobs.length;

        String[] folderNames = Arrays.copyOfRange(jobs, 1, length - 1);
        return getJob(Arrays.asList(folderNames), jobs[length - 1]);
    }

    /**
     * 获取构建进度
     */
    public StagesBuild getStagesBuild(JobWithDetails jobWithDetails, Long number) throws IOException {
        String jobUrl = jobWithDetails.getUrl();
        String stagesBuildUrl = jobUrl + "wfapi/runs?since=%23" + number;
        StagesBuild stagesBuild = client.getForList(stagesBuildUrl, StagesBuild.class).get(0);
        stagesBuild.setJobUrl(jobUrl);
        return stagesBuild;
    }

    /**
     * 获取最后一次构建日志
     */
    public BuildLogs getLastBuildLogs(List<String> folderNames, String jobName, Integer start) throws IOException {
        JobWithDetails job = getJob(folderNames, jobName);
        String url = job.getUrl();
        int number = job.getLastBuild().getNumber();
        return client.getBuildLogs(url + number + "/logText/progressiveHtml?start=" + start);
    }


    public BuildWithDetails waitUntilFinished(QueueReference queueRef) throws IOException, InterruptedException {
        QueueItem queueItem = getQueueItem(queueRef);
        JobWithDetails job = getJob(queueItem);
        while (!queueItem.isCancelled() && job.isInQueue()) {
            Thread.sleep(200);
            queueItem = getQueueItem(queueRef);
            job = getJob(queueItem);
        }

        if (queueItem.isCancelled()) {
            BuildWithDetails result = new BuildWithDetails(job.getLastBuild().details());
            result.setResult(BuildResult.CANCELLED);
            return result;
        }

        job = getJob(queueItem);
        Build lastBuild = job.getLastBuild();

        boolean isBuilding = lastBuild.details().isBuilding();
        while (isBuilding) {
            Thread.sleep(200);
            isBuilding = lastBuild.details().isBuilding();
        }

        return lastBuild.details();
    }

    /**
     * 检查目录是否不存在，如果不存在则创建
     */
    private void createIfNot(List<String> folderNames) throws IOException {
        if (!existJob(folderNames)) {
            int last = folderNames.size() - 1;
            createFolderForce(folderNames.subList(0, last), folderNames.get(last));
        }
    }

    private String toBasePath(List<String> folderNames) {
        StringBuilder sb = new StringBuilder("/");
        for (String folderName : folderNames) {
            sb.append(String.format("job/%s/", folderName));
        }
        return sb.toString();
    }

    private String toJobBaseUrl(List<String> folderNames, String jobName) {
        return toBasePath(folderNames) + "job/" + EncodingUtils.encode(jobName);
    }
}
