package com.offbytwo;

import com.offbytwo.jenkins.model.QueueReference;
import com.offbytwo.jenkins.service.JenkinsService;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class JenkinsServerTest {

    @Test
    public void test() throws IOException {
        JenkinsService jenkinsServer = new JenkinsService(("http://172.16.1.25:8080/"), "zhouxin", "c763c521f3cec2b5091f5fb670882316");
        String playBook = "---\n" +
                "- hosts: all\n" +
                "  tasks:\n" +
                "     - name: \"helloworld\"\n" +
                "       shell: echo \"Hello World\" `date` by `hostname`";

        Map<String, String> params = new HashMap<>();
        params.put("ANSIBLE_PLAYBOOK_CONTENT", playBook);
        params.put("ANSIBLE_HOSTS_CONTENT", "127.0.0.1");

        QueueReference queueReference = jenkinsServer.buildJob(Collections.<String>emptyList(), "ansible-test", params);
        System.out.println(queueReference);
    }

    @Test
    public void main1() throws FileNotFoundException {
        System.setOut(new PrintStream("out.txt"));
        System.out.println("123");
    }
}
